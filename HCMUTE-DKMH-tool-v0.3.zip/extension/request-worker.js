'use strict';
const routes={programs:['GET','Authen/GetAllStudyProgramRegist'],quota:['GET','Regist/GetRegistSemesterCreditQuota'],courses:['POST','Regist/GetAllClassAllowRegist'],sections:['POST','Regist/GetAllScheduleUnitAllowRegist'],registered:['POST','Regist/GetAllClassRegisted'],check:['POST','Regist/CheckExitsRegist'],submit:['POST','Regist/RegistScheduleStudyUnit']};
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message?.kind!=='dkmh-api')return;
  const senderUrl=new URL(sender.url||'https://invalid.local');
  if(sender.id!==chrome.runtime.id||senderUrl.origin!=='https://dkmh.hcmute.edu.vn'||!senderUrl.pathname.startsWith('/Student/')){reply({error:'Nguồn gọi không hợp lệ.'});return;}
  (async()=>{
    const {op,args:a={},token}=message;
    if(!routes[op]||typeof token!=='string'||!token)throw Error('Thiếu phiên đăng nhập hoặc thao tác không hợp lệ.');
    const config=await (await fetch(chrome.runtime.getURL('public-api-config.json'))).json();
    const [method,path]=routes[op],url=new URL(path,config.baseURL);let body;
    if(['quota','check','submit'].includes(op))url.searchParams.set('StudyProgramID',String(a.program));
    if(op==='submit'){url.searchParams.set('TurnID',String(a.turn));url.searchParams.set('Action','REGIST');}
    if(op==='courses')body={ReqParam1:a.program,ReqParam2:a.type,ReqParam3:a.year,ReqParam4:a.term,ReqParam5:a.search};
    if(op==='sections')body={ReqParam1:a.program,ReqParam2:a.type,ReqParam3:a.studyUnit};
    if(op==='registered')body={ReqParam1:a.rand,ReqParam2:a.turn};
    if(op==='check'||op==='submit'){if(!Array.isArray(a.payload)||a.payload.length<1||a.payload.length>3)throw Error('Payload lớp không hợp lệ.');body=a.payload;}
    const response=await fetch(url,{method,headers:{'content-type':'application/json',apiKey:config.apiKey,clientId:config.clientId,Authorization:'Bearer '+token},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(20000),redirect:'error',credentials:'omit'});
    if(!response.ok){const retry=response.headers.get('Retry-After');reply({error:'API trả HTTP '+response.status,status:response.status,retryAfter:retry?(Number(retry)*1000||Math.max(0,Date.parse(retry)-Date.now())):0});return;}
    reply({data:await response.json()});
  })().catch(()=>reply({error:'Không nhận được phản hồi API. Kiểm tra mạng/phiên đăng nhập.'}));
  return true;
});
