(function(root){
  'use strict';
  const key=v=>String(v??'').trim().toUpperCase();
  function parse(text){
    const courses=new Set();
    const plan=String(text).split(/\r?\n/).map(s=>s.trim()).filter(s=>s&&!s.startsWith('#')).map(line=>{
      const parts=line.split('|').map(s=>s.trim());
      if(parts.length!==2)throw Error('Mỗi dòng: Mã môn|Lớp LT+TH+BT > phương án khác');
      const course=key(parts[0]);if(!/^[A-Z0-9_.\/-]+$/.test(course)||courses.has(course))throw Error('Mã môn sai hoặc trùng dòng: '+course);courses.add(course);
      const alternatives=parts[1].split('>').map(s=>s.split('+').map(key));
      if(alternatives.some(a=>!a.length||a.length>3||new Set(a).size!==a.length||a.some(c=>! /^[A-Z0-9_.\/-]+$/.test(c))))throw Error('Mỗi phương án gồm 1–3 mã lớp khác nhau, nối bằng dấu +.');
      return {course,alternatives};
    });if(!plan.length)throw Error('Chưa nhập kế hoạch API.');return plan;
  }
  function objects(data){const found=[];function visit(v,depth){if(depth>10||!v||typeof v!=='object')return;if(!Array.isArray(v))found.push(v);for(const child of Object.values(v))if(child&&typeof child==='object')visit(child,depth+1);}visit(data,0);return found;}
  function bundle(rows,codes){
    const selected=codes.map(code=>{const matches=rows.filter(r=>key(r.ScheduleStudyUnitAlias)===code);if(matches.length!==1)throw Error('Mã lớp không duy nhất hoặc không tồn tại: '+code);return matches[0];});
    if(selected.some(r=>r.NumberOfChilds==null||r.NumberRegistOfEmpty==null||!Number.isInteger(Number(r.NumberOfChilds))||Number(r.NumberOfChilds)<0||!Number.isFinite(Number(r.NumberRegistOfEmpty))))throw Error('Phản hồi thiếu cấu trúc lớp con hoặc số chỗ; không gửi.');
    for(let i=1;i<selected.length;i++)if(String(selected[i].ParentID)!==String(selected[i-1].CurriculumID))throw Error('LT/TH/BT không cùng chuỗi lớp cha–con.');
    if(selected[0].ParentID && String(selected[0].ParentID)!=='0' && rows.some(r=>String(r.CurriculumID)===String(selected[0].ParentID)))throw Error('Phương án phải bắt đầu từ lớp gốc, kèm LT/TH/BT phụ thuộc.');
    for(let i=0;i<selected.length;i++)if(Number(selected[i].NumberOfChilds)>0 && !selected[i+1])throw Error('Thiếu lớp TH/BT của '+codes[i]);
    if(selected.some(r=>r.CurriculumID==null||r.ScheduleStudyUnitID==null))throw Error('Phản hồi lớp thiếu ID; cần kiểm tra lại API.');
    return selected;
  }
  function receipt(rows,payload){return payload.every(p=>rows.some(r=>String(r.ScheduleStudyUnitID)===String(p.ScheduleStudyUnitID)));}
  function create({rpc,store,wait,notify=()=>{},signal}){
    const check=()=>{if(signal?.aborted)throw new DOMException('Đã dừng','AbortError');};
    async function read(op,args){for(let n=0;;n++){check();try{return await rpc(op,args);}catch(e){if(e.status===401||e.status===403||e.status===400||n>=4)throw e;const delay=Math.min(60000,Math.max(Number(e.retryAfter)||0,2000*2**n));notify('Mạng/API chưa phản hồi; thử đọc lại sau '+Math.ceil(delay/1000)+' giây.');await wait(delay,signal);}}}
    async function context(program){const cfg=await read('quota',{program});if(cfg?.isChanDSSVDK)throw Error('Tài khoản bị chặn đăng ký; hãy kiểm tra với trường.');if(!cfg||!cfg.RegistAble||cfg.IdDot==null||cfg.RandID==null)throw Object.assign(Error('Đợt đăng ký chưa mở hoặc tài khoản chưa được phép đăng ký.'),{closed:true});return cfg;}
    async function registered(cfg){const response=await read('registered',{rand:String(cfg.RandID),turn:String(cfg.IdDot)});if(!response||!Array.isArray(response.Rows))throw Error('Không đọc được cấu trúc bảng kết quả API.');return response.Rows;}
    async function resolve(program,type,cfg,item){
      const data=await read('courses',{program,type,year:cfg.YearStudy,term:cfg.TermID,search:item.course});
      const matches=objects(data).filter(r=>r.StudyUnitID!=null&&(key(r.CurriculumID)===item.course||key(r.StudyUnitID)===item.course));
      const ids=[...new Set(matches.map(r=>String(r.StudyUnitID)))];if(ids.length!==1)throw Error('Không xác định duy nhất môn '+item.course+' từ danh sách được phép đăng ký.');
      const rows=await read('sections',{program,type,studyUnit:ids[0]});if(!Array.isArray(rows))throw Error('Danh sách lớp API không đúng định dạng.');return {rows,studyUnit:ids[0]};
    }
    async function prepare(program,type,plan){const cfg=await context(program),current=await registered(cfg),result=[];for(const item of plan){const data=await resolve(program,type,cfg,item);for(const codes of item.alternatives){const payload=bundle(data.rows,codes);result.push({course:item.course,codes,ready:!payload.some(p=>Number(p.NumberRegistOfEmpty)<=0),done:receipt(current,payload)});}}return result;}
    async function run({program,type,plan,scope,identity,interval=30000,maxMinutes=0,waitForOpen=false}){
      if(!scope?.trim()||!identity)throw Error('Thiếu đợt hoặc định danh phiên.');
      if(interval<15000||!Number.isFinite(interval)||!Number.isFinite(maxMinutes)||maxMinutes<0)throw Error('Chu kỳ tối thiểu 15 giây; giới hạn phút phải từ 0.');
      const deadline=maxMinutes?Date.now()+maxMinutes*60000:Infinity;
      let cfg;while(!cfg){check();if(Date.now()>=deadline){notify('Đã hết thời gian chờ mở đăng ký.');return;}try{cfg=await context(program);}catch(e){if(!e.closed||!waitForOpen)throw e;notify('Đợt chưa mở. Đang chờ kiểm tra lại…');await wait(interval,signal);}}
      const turn=String(cfg.IdDot);const namespace='api:'+identity+':'+program+':'+turn+':'+scope;
      const journal=await store.get(namespace)||{};const save=()=>store.set(namespace,journal);
      while(Date.now()<deadline){check();cfg=await context(program);if(String(cfg.IdDot)!==turn)throw Error('Đợt đăng ký đã thay đổi; dừng để kiểm tra.');let current=await registered(cfg),waiting=0;
        for(const item of plan){check();const id=item.course,data=await resolve(program,type,cfg,item);const options=item.alternatives.map(codes=>({codes,payload:bundle(data.rows,codes)}));
          const done=options.find(o=>receipt(current,o.payload));if(done){journal[id]={state:'done',codes:done.codes};await save();notify(id+': đã xác minh ✓');continue;}
          if(['pending','uncertain','done'].includes(journal[id]?.state))throw Error(id+': lần gửi trước chưa đối soát được. Không tự gửi lại.');
          if(current.some(r=>String(r.StudyUnitID)===data.studyUnit))throw Error(id+': đã có lớp khác của môn này. Cần dùng Chuyển nhóm.');
          let completed=false;
          for(const option of options){check();if(option.payload.some(p=>Number(p.NumberRegistOfEmpty)<=0)){notify(id+': lớp đầy, xét phương án tiếp theo.');continue;}
            const tested=await read('check',{program,payload:option.payload});
            if(!tested||typeof tested.IsConflict!=='boolean'||typeof tested.IsFull!=='boolean')throw Error('Phản hồi kiểm tra điều kiện không đúng định dạng; không gửi.');
            if(tested.IsFull||tested.IsConflict){notify(id+': '+String(tested.Message||'Đầy lớp hoặc xung đột'));continue;}
            // Durable journal before the only mutating RPC. Never automatically retry a write.
            journal[id]={state:'pending',codes:option.codes,at:new Date().toISOString()};await save();check();
            let sendError;
            try{await rpc('submit',{program,turn,payload:option.payload});}catch(e){sendError=e;}
            try{
              for(let n=0;n<6;n++){check();current=await registered(cfg);if(receipt(current,option.payload)){completed=true;break;}if(sendError?.status===401||sendError?.status===403)break;await wait(1500,signal);}
            }catch(e){journal[id].state='uncertain';await save();throw e;}
            if(!completed){journal[id].state='uncertain';await save();throw Error(id+': đã gửi nhưng chưa xác minh kết quả. Dừng, không gửi lớp thay thế.');}
            journal[id]={state:'done',codes:option.codes,at:new Date().toISOString()};await save();notify(id+': thành công '+option.codes.join(' + '));break;
          }
          if(!completed)waiting++;
        }
        if(!waiting){notify('Hoàn tất kế hoạch API.');return;}
        notify(waiting+' môn đang chờ; kiểm tra lại sau '+interval/1000+' giây.');await wait(Math.min(interval,Math.max(1,deadline-Date.now())),signal);
      }notify('Đã hết giới hạn thời gian chờ.');
    }
    return {prepare,run};
  }
  const api={parse,objects,bundle,receipt,create};root.DKMHRequest=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
