(()=>{
  'use strict';
  const host=document.getElementById('hcmute-dkmh-tool');if(!host||!globalThis.DKMHRequest)return;
  const main=host.shadowRoot.querySelector('main');
  const entry=document.createElement('details');entry.innerHTML=`<summary>⚡ Đăng ký bằng API · dùng từ lần đầu</summary><p class="muted">Chế độ mới, chưa kiểm thử đăng ký trên hệ thống trường. Không cần ánh xạ nút/bảng hoặc đăng ký mẫu. Dùng kế hoạch riêng bên dưới; giữ tab mở.</p><button id="apiPrograms">Tải chương trình từ API</button><label>Chương trình</label><select id="apiProgram"><option value="">Tải danh sách trước</option></select><label>Kiểu đăng ký</label><select id="apiType"><option value="KH">Theo kế hoạch (KH)</option><option value="NKH">Ngoài kế hoạch (NKH)</option><option value="NCT">Ngoài chương trình (NCT)</option></select><label>Tên đợt để lưu nhật ký</label><input id="apiScope" placeholder="VD: HK2 2026–2027"><label>Kế hoạch API: Mã môn|LT+TH+BT &gt; phương án khác</label><textarea id="apiPlan" rows="5" placeholder="MATH|MATH_LT01+MATH_TH01 > MATH_LT02+MATH_TH02&#10;PHY|PHY_01"></textarea><p class="muted">Mã giả. Chọn đủ các lớp con bắt buộc của từng môn. Mỗi dòng một môn, mỗi phương án là một giao dịch. Dấu &gt; phân tách các phương án thay thế.</p><div class="row"><div><label>Kiểm tra lại (giây)</label><input id="apiInterval" type="number" min="15" value="30"></div><div><label>Dừng sau (phút, 0 = không giới hạn)</label><input id="apiMinutes" type="number" min="0" value="0"></div></div><div class="toolbar"><button id="apiPreview">Xem trước API</button><button id="apiStart" class="primary">Chạy API</button><button id="apiStop" class="danger" disabled>Dừng API</button></div><pre id="apiLog">Chưa chạy API.</pre>`;
  main.prepend(entry);const $=id=>entry.querySelector('#'+id);let running=false,controller;const R=DKMHRequest;
  let expectedAccount;
  const log=text=>{const lines=($('apiLog').textContent+'\n'+text).split('\n');$('apiLog').textContent=lines.slice(-100).join('\n');};
  const storage={async get(k){return(await chrome.storage.local.get(k))[k];},async set(k,v){await chrome.storage.local.set({[k]:v});}};
  function session(){const a=JSON.parse(localStorage.getItem('authorizationData')||'null');if(!a?.Token||a.Id==null)throw Error('Hãy tự đăng nhập vào trang trường trước.');return a;}
  async function rpc(op,args){const account=session();if(expectedAccount!=null&&String(account.Id)!==expectedAccount)throw Object.assign(Error('Tài khoản đã thay đổi. Dừng và chọn lại kế hoạch.'),{status:401});const response=await chrome.runtime.sendMessage({kind:'dkmh-api',op,args,token:account.Token});if(!response||response.error){const e=Error(response?.error||'Không kết nối được tiện ích.');e.status=response?.status;e.retryAfter=response?.retryAfter;throw e;}return response.data;}
  function wait(ms,signal){return new Promise((resolve,reject)=>{if(signal?.aborted)return reject(new DOMException('Đã dừng','AbortError'));const abort=()=>{clearTimeout(t);signal.removeEventListener('abort',abort);reject(new DOMException('Đã dừng','AbortError'));};const t=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},ms);signal?.addEventListener('abort',abort,{once:true});});}
  function busy(value){running=value;entry.querySelectorAll('button,input,select,textarea').forEach(el=>el.disabled=value);$('apiStop').disabled=!value;}
  const fields=['apiProgram','apiType','apiScope','apiPlan','apiInterval','apiMinutes'];
  async function save(){const value={};fields.forEach(k=>value[k]=$(k).value);await storage.set('api-settings',value);}
  async function programs(){const rows=await rpc('programs',{});if(!Array.isArray(rows))throw Error('Danh sách chương trình không đúng cấu trúc.');$('apiProgram').replaceChildren();for(const row of rows){if(row.StudyProgramID==null)continue;const o=document.createElement('option');o.value=String(row.StudyProgramID);o.textContent=String(row.StudyProgramID)+(row.IsOpen?' · đang mở':'');$('apiProgram').append(o);}if(!$('apiProgram').options.length)throw Error('Chưa có chương trình được phép đăng ký.');log('Đã tải chương trình. Chọn đúng chương trình trước khi chạy.');}
  $('apiPrograms').onclick=async()=>{try{busy(true);await programs();await save();}catch(e){log(e.message);}finally{busy(false);}};
  async function execute(preview){
    if(running)return;busy(true);controller=new AbortController();
    try{
      await save();const a=session(),program=$('apiProgram').value,type=$('apiType').value,plan=R.parse($('apiPlan').value);expectedAccount=String(a.Id);if(!program)throw Error('Chọn chương trình trước.');
      if(!navigator.locks)throw Error('Trình duyệt cần hỗ trợ Web Locks.');
      await navigator.locks.request('hcmute-dkmh-single-runner',{ifAvailable:true},async lock=>{
        if(!lock)throw Error('Tab hoặc chế độ khác đang chạy tool.');const engine=R.create({rpc,store:storage,wait,notify:log,signal:controller.signal});
        if(preview){const result=await engine.prepare(program,type,plan);result.forEach(r=>log(r.course+': '+r.codes.join(' + ')+' · '+(r.done?'đã đăng ký':r.ready?'còn chỗ':'đang đầy')));log('Xem trước xong. Chưa gửi đăng ký.');return;}
        const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(a.Id)));const identity=Array.from(new Uint8Array(digest)).map(n=>n.toString(16).padStart(2,'0')).join('');
        await engine.run({program,type,plan,scope:$('apiScope').value,identity,interval:Number($('apiInterval').value)*1000,maxMinutes:Number($('apiMinutes').value),waitForOpen:true});
      });
    }catch(e){log(e.name==='AbortError'?'Đã dừng. Yêu cầu đã gửi vẫn có thể hoàn tất; chạy lại sẽ đối soát trước.':e.message);}finally{expectedAccount=undefined;busy(false);}
  }
  $('apiPreview').onclick=()=>execute(true);$('apiStart').onclick=()=>execute(false);$('apiStop').onclick=()=>{controller?.abort();log('Đang dừng; chờ thao tác đang xử lý kết thúc.');};
  fields.forEach(k=>$(k).addEventListener('change',()=>save().catch(e=>log(e.message))));
  storage.get('api-settings').then(v=>{if(!v)return;for(const k of fields)if(v[k]!=null){if(k==='apiProgram'&&v[k]){const option=document.createElement('option');option.value=v[k];option.textContent=v[k]+' · đã lưu, cần tải lại để xác minh';$(k).append(option);}$(k).value=v[k];}}).catch(e=>log(e.message));
})();
