# Kết quả kiểm tra bản 0.1.0

## Bản 0.3 API

Kết quả cuối `npm test`: **28/28 kiểm tra đạt**; cả ba file request-engine.js, request-worker.js, request-panel.js qua `node --check`.

Thêm kiểm tra engine request và worker bằng API giả lập: LT/TH gửi cùng giao dịch, ràng buộc cha–con, payload từ phản hồi, lớp ưu tiên đầy, đăng ký thành công, mất phản hồi nhưng đối soát thành công, kết quả chưa rõ chặn gửi lại, lỗi lưu nhật ký chặn gửi, đợt đóng, xung đột, backoff HTTP 429, hết phiên, dừng khi chờ mở, dữ liệu thiếu số chỗ, giới hạn nguồn gọi/URL/payload worker. Không gửi đăng ký thật. Chưa kiểm thử cài extension hoặc panel API trong Chrome/Edge thật.

## Bản 0.2 theo video

`npm test`: **12/12 nhóm kiểm tra logic đạt**. Bổ sung parser định dạng video, nhóm lớp ưu tiên, tách LT/TH, wildcard giảng viên/lịch, kế hoạch chuyển nhóm và kiểm tra cấu hình checkbox/chương trình/môn cha.

**24/24 tình huống tích hợp đạt** trong trình duyệt trên trang mô phỏng loopback, dùng mã nguồn cuối của bản 0.2. Bao gồm 13 tình huống cũ và 11 tình huống mới: lớp ưu tiên đầy chuyển sang lớp kế tiếp; lớp ưu tiên đầu thành công bỏ các lớp khác; tách LT/TH; wildcard; chặn sai giảng viên; tạo kế hoạch bằng bảng chọn lớp; gửi nhiều lớp qua checkbox theo từng lần; chặn checkbox ngoài kế hoạch; mở môn cha; chọn chương trình/chế độ; chuyển nhóm chỉ hoàn tất khi lớp mới có và lớp cũ không còn.

Đã sửa lỗi trạng thái cũ hiển thị ở đầu lần chạy mới, kiểm tra nhãn Chuyển nhóm bị trùng một phần với từ Hủy và nhãn checkbox chứa mã lớp thay đổi giữa các dòng.

Chưa kiểm thử gửi đăng ký lên hệ thống trường hoặc cài extension thực tế vào Chrome/Edge. Mô phỏng dùng localStorage riêng thay cho chrome.storage.local. Chưa kiểm thử tự động nạp/tải file qua hộp thoại trình duyệt; parser và tuần tự hóa kế hoạch đã có kiểm tra logic. Cần ánh xạ và xác minh DOM thực tế khi đợt đăng ký mở.

## Kết quả lưu từ bản 0.1

Ngày kiểm tra: 23/10/2026. Node.js 22.20.0; mô phỏng tích hợp chạy trong Chrome qua server loopback.

- `npm test`: **6/6 nhóm kiểm tra đạt** — nhập và loại trùng mã, kiểm tra đầu vào, tiếng Việt, số chỗ còn lại, phân loại thông báo và cấu hình.
- `node --check`: cú pháp `content.js`, `fixture.js`, `server.cjs` hợp lệ.
- Manifest JSON hợp lệ; các content script tồn tại; quyền khai báo chỉ gồm `storage`.
- Mô phỏng tích hợp dùng cùng `extension/core.js` và `extension/content.js`: **13/13 tình huống đạt**.

Các tình huống tích hợp:

1. Xem trước không gửi đăng ký.
2. Hai mã chạy tuần tự; mã trùng bị bỏ; kết quả được đối soát trong bảng. Có kiểm tra bấm nút Bắt đầu nhanh hai lần.
3. Chạy lại không gửi mã đã hoàn tất.
4. Lớp còn 0 chỗ không phát sinh lần gửi.
5. Lớp đầy rồi có chỗ được đăng ký ở vòng kế tiếp.
6. Lỗi điều kiện học vụ không bị thử lặp.
7. Dừng giữa lần gửi giữ trạng thái `uncertain`.
8. Trạng thái chưa rõ chặn lần gửi tiếp theo.
9. Dừng khi đang chờ không phát sinh đăng ký.
10. Nút đổi thành Hủy bị chặn.
11. Nhiều dòng cùng mã bị chặn.
12. Web Lock đang được giữ chặn phiên chạy đồng thời.
13. Chọn nút mẫu không thực hiện đăng ký.

Chưa xác minh: cài tiện ích thật vào Chrome, DOM đăng ký trong đợt mở, phân trang/nhóm lớp, thông báo của hệ thống trường và gửi đăng ký thật. Kiểm thử mô phỏng dùng kho lưu riêng trong localStorage; bản cài thật dùng chrome.storage.local. Không có đăng ký/hủy thật nào được thực hiện trong khảo sát hoặc kiểm thử.
