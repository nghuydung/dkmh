# Luồng đăng ký lần đầu — khảo sát mã công khai

**Cập nhật v0.3:** đã thêm worker, API engine và panel sử dụng riêng theo luồng dưới đây; xem API-GUIDE.md. Ghi nhận trạng thái v0.2 cuối tài liệu là lịch sử trước bản nâng cấp. Chưa xác minh đăng ký với máy chủ thật.

Nguồn đọc trực tiếp ngày 23/10/2026:

- https://dkmh.hcmute.edu.vn/static/js/main.b28378cb.js
- https://dkmh.hcmute.edu.vn/static/js/525.bde98f81.chunk.js

Không sử dụng tài khoản/token, không gửi request đăng ký hoặc hủy đăng ký trong khảo sát.

Bundle chính khai báo API base `https://dangkyapi.hcmute.edu.vn/api/`. Module 4089 trong chunk 525 cung cấp các hàm lấy chương trình/kiểu đăng ký, danh sách môn, danh sách lớp, kiểm tra xung đột, đăng ký và đọc kết quả. Không cần lịch sử đăng ký hay ghi lại lần đăng ký đầu tiên để biết các endpoint này.

Các endpoint được quan sát trong nguồn:

- GET `Authen/GetAllStudyProgramRegist`
- GET `Authen/GetAllStudyType`
- POST `Regist/GetAllClassAllowRegist`
- POST `Regist/GetAllScheduleUnitAllowRegist`
- POST `Regist/CheckExitsRegist?StudyProgramID=...`
- POST `Regist/RegistScheduleStudyUnit?TurnID=...&Action=REGIST&StudyProgramID=...`
- POST `Regist/GetAllClassRegisted`

Giao diện lấy lớp từ `GetAllScheduleUnitAllowRegist` với ReqParam1=chương trình, ReqParam2=kiểu đăng ký, ReqParam3=StudyUnitID của môn. Payload đăng ký là các đối tượng lớp lấy từ phản hồi đó, không chỉ một chuỗi mã lớp. Mã giao diện chọn theo CurriculumID và kiểm tra ParentID/NumberOfChilds. Nếu có lớp con, phải chọn đúng lớp thực hành; nếu lớp con tiếp tục có con thì cần lớp bài tập. Các lớp liên quan được gửi chung trong một mảng. Đây không phải bằng chứng API cho phép gộp nhiều môn độc lập tùy ý.

Luồng gọi kiểm tra trước khi gửi. Phản hồi kiểm tra có IsConflict, IsFull, Message; không được bỏ qua xung đột/đầy lớp. Mã giao diện có xử lý HTTP 429 (thao tác quá nhanh), vì vậy gửi song song nhiều request chưa được xác minh là phù hợp.

Trạng thái: xác định từ mã nguồn, chưa kiểm chứng với phiên đăng ký thực tế. Bản tiện ích v0.2 vẫn dùng DOM; chưa tích hợp các endpoint này. Không được quảng bá v0.2 là bản gửi request trực tiếp hoặc đã hỗ trợ đầy đủ giao dịch LT/TH/bài tập phụ thuộc. API adapter cần thêm bước lấy cấu hình đợt hiện hành, phiên đăng nhập, payload từ phản hồi thật, đối soát và kiểm thử trước khi đánh dấu sẵn sàng.
