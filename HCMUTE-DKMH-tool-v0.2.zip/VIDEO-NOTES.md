# Tham khảo video người dùng cung cấp

Nguồn: `đăng ký môn học hcmute.mp4`, khoảng 29 phút 58 giây. Đọc hình ảnh theo các mốc 15 giây và trích khung chi tiết để kiểm tra chữ/luồng thao tác; không dựa vào lời thoại chưa được phiên âm.

Các chức năng quan sát và phần triển khai tương ứng:

| Mốc gần đúng | Nội dung video | Bản 0.2 |
| --- | --- | --- |
| 06:37 | Chương trình đào tạo, 3 kiểu đăng ký | Chọn chương trình và chế độ qua giao diện trường |
| 07:22–08:37 | Chọn môn rồi chọn lớp thực hành | Bảng môn cha, mở lớp, bảng chọn LT/TH |
| 09:37–12:22 | Chọn nhiều môn/lớp, thống kê kết quả | Kế hoạch nhiều nhóm, nhật ký và bảng trạng thái |
| 13:37–14:07 | Chuyển nhóm từ kết quả đăng ký | Ánh xạ nút chuyển nhóm riêng, đối soát lớp cũ và mới |
| 15:22–17:07 | Nhiều lựa chọn, lớp đủ số lượng tiếp tục chờ | Nhóm lớp ưu tiên, thử lựa chọn tiếp theo, chờ vòng sau |
| 17:37–18:37 | Ngoài chương trình, tìm môn và chọn lớp | Chế độ ngoài chương trình, lọc bảng đã hiển thị và mở môn |
| 20:52–25:15 | Nhập Mã môn\|Giảng viên\|Lịch học\|Mã LHP | Parser 4 cột, tùy chọn cột LT/TH và mã lớp cũ; wildcard * |
| 25:22–28:22 | Thành công/không hợp lệ/đầy, Stop | Phân loại kết quả, chờ chỗ, dừng và chặn gửi lặp khi chưa rõ kết quả |

Không dùng thông tin đăng nhập, cookie, tài khoản hoặc mã VIP xuất hiện trong video. Không sao chép hình ảnh hoặc mã nguồn dịch vụ vào sản phẩm. Bản nâng cấp dùng phiên đăng nhập trên trang trường và các thành phần giao diện được người dùng ánh xạ; chưa xác minh với giao diện đăng ký đang mở của trường.
