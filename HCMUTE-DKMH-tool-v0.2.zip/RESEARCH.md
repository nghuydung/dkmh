# Ghi nhận khảo sát · 23/10/2026

Trang do người dùng cung cấp: `https://dkmh.hcmute.edu.vn/Student/RegistScheduleUnit`.

Quan sát trực tiếp trong tab được người dùng chỉ định:

- Phiên đã đăng nhập. Không đưa tên, mã sinh viên hoặc thông tin tài khoản vào mã nguồn.
- Trang đăng ký hiển thị “Chương trình đào tạo”, bộ chọn có một lựa chọn trong phiên khảo sát và nút “Làm mới”. Sau khi chọn chương trình và bấm Làm mới, chưa thấy bảng lớp hoặc bảng đã đăng ký. Chưa xác định được nguyên nhân từ giao diện.
- Bộ chọn dùng MUI Select: `div[role="button"][aria-haspopup="listbox"]`, không phải thẻ select HTML. Giá trị ID `-select` không dùng làm bộ điều khiển đăng ký.
- Menu “Tra cứu học phần” mở `/Student/FilterScheduleUnit`. Có lựa chọn “Mã học phần” hoặc “Tên học phần”, ô `input[name="txtSearch"]`, nút “Tìm kiếm”.
- Bảng tra cứu có các cột: STT, Mã LHP, Tên HP, STC, Loại, Thông tin, Giảng viên, Giới hạn, Từ ngày, Đến ngày.
- Tìm khi để trống báo “Vui lòng nhập thông tin tìm kiếm”. Tra cứu mẫu theo tên chưa trả dòng dữ liệu trong thời điểm quan sát.
- Không bấm đăng ký/hủy lớp thật. Chưa quan sát nút đăng ký, hộp thoại xác nhận, bảng kết quả thực tế hoặc API đăng ký. Không suy đoán endpoint hay cấu trúc payload.

Vì chưa có giao diện đăng ký đầy đủ, bản tool dùng thao tác DOM và ánh xạ thành phần do người dùng chọn khi bảng xuất hiện. Cần xác minh sau: cấu trúc bảng đăng ký, mã nhóm LT/TH, nút trực tiếp hay checkbox, hành vi refresh, phân trang/lọc, hộp thoại và tín hiệu kết quả.

Thiết kế tiện ích dựa trên [content scripts của Chrome](https://developer.chrome.com/docs/extensions/develop/concepts/content-scripts). Cách cài bản unpacked theo [hướng dẫn chính thức](https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked).
