(() => {
  const scope = 'DEMO-INTEGRATION';
  const settings = {scope, codes:'MATH_01\nPHY_02', interval:15, duration:0, startAt:'', available:'#available', availableHeaders:['stt','ma lhp','ten hp','con cho','thao tac','giang vien','lich hoc'], registered:'#registered', registeredHeaders:['stt','ma lhp','ten hp','thao tac'], action:'button:nth-of-type(1)', actionLabel:'dang ky', codeColumn:2, registeredColumn:2, seatColumn:4, refresh:'#refresh', refreshLabel:'lam moi'};
  localStorage.setItem('dkmh-demo:settings', JSON.stringify(settings));
  localStorage.setItem('dkmh-demo:ledger:' + scope, '{}');
  let clicks = 0, behavior = 'success', seats = 1, refreshes = 0, perCodeSeats={}, clickedCodes=[], courseOpens=0, batchSends=0, switchSource='';
  const body = document.querySelector('#available tbody');
  function appendRegistered(code) {
    const result=document.createElement('tr');
    for(const value of [1,code,'Học phần mô phỏng']) {const cell=document.createElement('td');cell.textContent=value;result.append(cell);}
    const td=document.createElement('td'),button=document.createElement('button');button.textContent='C.Nhóm';button.onclick=()=>{switchSource=code;};td.append(button);result.append(td);document.querySelector('#registered tbody').append(result);
  }
  function send(code,switching=false) {
    clicks++;clickedCodes.push(code);
    if(behavior==='unknown')return;
    if(behavior==='full'){document.getElementById('notice').textContent='Lớp đã đầy '+clicks;return;}
    if(behavior==='blocked'){document.getElementById('notice').textContent='Trùng lịch học '+clicks;return;}
    setTimeout(()=>{
      if(switching && switchSource) for(const row of document.querySelectorAll('#registered tbody tr'))if(row.cells[1].textContent===switchSource)row.remove();
      appendRegistered(code);
    },150);
  }
  function render(codes = ['MATH_01','PHY_02']) {
    body.replaceChildren();
    for (const code of codes) {
      const tr = document.createElement('tr');
      for (const value of [body.children.length+1,code,'Học phần mô phỏng',perCodeSeats[code] ?? seats]) {const td=document.createElement('td');td.textContent=value;tr.append(td);}
      const td=document.createElement('td'), b=document.createElement('button'),cb=document.createElement('input'),sw=document.createElement('button');cb.type='checkbox';cb.setAttribute('aria-label','Chọn lớp '+code);b.textContent='Đăng ký';sw.textContent='Chuyển';td.append(cb,b,sw);tr.append(td);
      b.onclick=()=>send(code);sw.onclick=()=>send(code,true);
      for(const text of ['GV Demo','Thứ 2, tiết 1-3']){const cell=document.createElement('td');cell.textContent=text;tr.append(cell);}
      body.append(tr);
    }
  }
  document.getElementById('refresh').onclick=()=>{refreshes++;}; render();
  document.getElementById('open-course').onclick=()=>{courseOpens++;};
  document.getElementById('submit-common').onclick=()=>{batchSends++;for(const row of body.rows)if(row.querySelector('input').checked)send(row.cells[1].textContent);};
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  async function until(fn, timeout=10000){const deadline=Date.now()+timeout;while(!fn()){if(Date.now()>deadline)throw new Error('Timeout');await wait(50);}}
  document.getElementById('suite').onclick=async()=>{
    const out=document.getElementById('results');out.textContent='Đang kiểm tra…';
    const ui=document.getElementById('hcmute-dkmh-tool').shadowRoot;
    const $=id=>ui.getElementById(id);
    const report=text=>{out.textContent+='\n'+text;};
    const check=(value,text)=>{if(!value)throw new Error(text);report('PASS · '+text);};
    const ledger=()=>JSON.parse(localStorage.getItem('dkmh-demo:ledger:'+scope)||'{}');
    async function stop(){if(!$('stop').disabled){$('stop').click();await until(()=>$('stop').disabled);}}
    async function reset(codes){await stop();localStorage.setItem('dkmh-demo:ledger:'+scope,'{}');document.querySelector('#registered tbody').replaceChildren();document.getElementById('notice').textContent='';$('codes').value=codes;clicks=0;refreshes=0;seats=1;behavior='success';perCodeSeats={};clickedCodes=[];batchSends=0;courseOpens=0;switchSource='';render();}
    async function pick(key,element){$('mapping').open=true;ui.querySelector('[data-pick="'+key+'"]').click();element.click();await until(()=>$('status').textContent.includes('Đã lưu lựa chọn'));}
    try {
      await until(()=>$('log').textContent.includes('Đã tải'));
      await reset('MATH_01\nPHY_02\nMATH_01');
      $('previewButton').click();await until(()=>$('status').textContent.includes('Xem trước hoàn tất'));
      check(clicks===0,'Xem trước không gửi đăng ký');
      $('start').click();$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===2 && ledger().MATH_01.state==='done' && ledger().PHY_02.state==='done','Đăng ký hai mã tuần tự; bỏ mã trùng; đối soát thành công');
      await until(()=>$('stop').disabled);$('start').click();await until(()=>!$('stop').disabled);await until(()=>$('stop').disabled);
      check(clicks===2,'Chạy lại không đăng ký trùng mã đã hoàn tất');
      await reset('MATH_01');seats=0;render();$('start').click();await until(()=>$('status').textContent.includes('lớp chờ'));
      check(clicks===0,'Lớp hết chỗ không bị gửi yêu cầu');
      seats=1;render();await until(()=>$('status').textContent.startsWith('Hoàn tất'),22000);
      check(clicks===1 && refreshes>=2,'Chờ qua vòng kiểm tra tiếp theo và tự đăng ký khi có chỗ');
      await reset('MATH_01');behavior='blocked';$('start').click();await until(()=>$('stop').disabled && ledger().MATH_01?.state==='blocked');
      check(clicks===1,'Lỗi điều kiện học vụ không bị thử lặp');
      await reset('MATH_01');behavior='unknown';$('start').click();await until(()=>clicks===1);$('stop').click();await until(()=>$('stop').disabled);
      check(ledger().MATH_01.state==='uncertain','Dừng giữa lần gửi giữ trạng thái chưa rõ kết quả');
      $('start').click();await until(()=>$('status').textContent.includes('Cần kiểm tra kết quả trước đó'));
      check(clicks===1,'Chặn gửi lặp sau kết quả chưa rõ');
      await reset('MATH_01');seats=0;render();$('start').click();await until(()=>!$('stop').disabled);$('stop').click();await until(()=>$('stop').disabled);
      check(clicks===0,'Dừng khi đang chờ không phát sinh đăng ký');
      await reset('MATH_01');body.querySelector('button').textContent='Hủy';$('start').click();await until(()=>$('status').textContent.includes('Nhãn nút thay đổi'));
      check(clicks===0,'Chặn nút thay đổi thành Hủy');
      await reset('MATH_01');const clone=body.firstElementChild.cloneNode(true);body.append(clone);$('start').click();await until(()=>$('status').textContent.includes('nhiều dòng'));
      check(clicks===0,'Mã lớp xuất hiện nhiều dòng phải được làm rõ');
      await reset('MATH_01');let release;const held=navigator.locks.request('hcmute-dkmh-single-runner',()=>new Promise(r=>{release=r;}));await until(()=>Boolean(release));
      $('start').click();await until(()=>$('status').textContent.includes('tab khác'));release();await held;
      check(clicks===0,'Chặn chạy đồng thời từ tab khác');
      await reset('MATH_01');$('mapping').open=true;ui.querySelector('[data-pick="action"]').click();body.querySelector('button').click();await until(()=>$('status').textContent.includes('Đã lưu lựa chọn'));
      check(clicks===0,'Chọn nút mẫu không thực hiện đăng ký');
      await reset('MATH_01 > PHY_02');perCodeSeats.MATH_01=0;render();$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===1 && clickedCodes[0]==='PHY_02','Lớp ưu tiên đầy thì tự chọn lớp thay thế, chỉ đăng ký một lớp');
      await reset('MATH_01 > PHY_02');$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===1 && clickedCodes[0]==='MATH_01','Ưu tiên đầu thành công thì bỏ tất cả lớp thay thế');
      await reset('DEMO|*|*|MATH_01|LT\nDEMO|*|*|PHY_02|TH');$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===2,'Cùng môn nhưng lý thuyết và thực hành được xử lý riêng');
      await reset('DEMO|GV*|Thứ 2*|MATH_01');$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===1,'Định dạng video và bộ lọc giảng viên/lịch hỗ trợ wildcard');
      await reset('DEMO|GV Khác|*|MATH_01');$('start').click();await until(()=>$('status').textContent.includes('lớp chờ'));await stop();
      check(clicks===0 && ledger().MATH_01.state==='mismatch','Không gửi lớp sai giảng viên đã yêu cầu');
      await reset('');$('catalogDetails').open=true;$('catalogCourse').value='DEMO';$('scanCatalog').click();await until(()=>$('catalog').querySelectorAll('input[type="checkbox"]').length===2);
      $('catalog').querySelectorAll('input')[0].click();$('catalog').querySelectorAll('input')[1].click();$('addCatalog').click();await until(()=>$('status').textContent.includes('Đã thêm'));
      check(DKMHCore.parsePlan($('codes').value)[0].candidates.length===2 && clicks===0,'Bảng chọn lớp tạo nhóm ưu tiên, chưa gửi đăng ký');
      await reset('MATH_01\nPHY_02');await pick('action',body.querySelector('input'));await pick('batchSubmit',document.getElementById('submit-common'));
      $('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===2 && batchSends===2,'Checkbox và nút Đăng ký chung gửi tuần tự đúng từng lớp');
      await reset('MATH_01');body.rows[1].querySelector('input').checked=true;$('start').click();await until(()=>$('status').textContent.includes('checkbox của lớp khác'));
      check(clicks===0,'Chặn gửi khi còn checkbox ngoài kế hoạch đang được chọn');
      await reset('DEMO|*|*|MATH_01');await pick('action',body.querySelector('button'));await pick('courses',document.querySelector('#courses td'));await pick('courseAction',document.getElementById('open-course'));
      $('courseColumn').value=2;$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===1 && courseOpens===1,'Mở môn cha trước khi đăng ký lớp con');
      $('clearCourses').click();await wait(100);
      await reset('MATH_01');await pick('programControl',document.getElementById('program'));$('programValue').value='CT-B';$('registrationMode').value='outside';$('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(document.getElementById('program').value==='B' && document.querySelector('input[value="outside"]').checked,'Chọn chương trình đào tạo và kiểu đăng ký trước khi gửi');
      $('programValue').value='';$('registrationMode').value='current';
      await reset('DEMO|*|*|MATH_01|LT|MATH_OLD');appendRegistered('MATH_OLD');await pick('switchAction',document.querySelector('#registered button'));await pick('switchTarget',body.rows[0].querySelectorAll('button')[1]);
      $('start').click();await until(()=>$('status').textContent.startsWith('Hoàn tất'));
      check(clicks===1 && ![...document.querySelectorAll('#registered tbody tr')].some(r=>r.cells[1].textContent==='MATH_OLD') && ledger().MATH_01.state==='done','Chuyển nhóm xác minh lớp mới có và lớp cũ đã được thay thế');
      report('HOÀN TẤT · toàn bộ tình huống tích hợp đã qua.');
    } catch(e){await stop();report('FAIL · '+e.message);}
  };
})();
