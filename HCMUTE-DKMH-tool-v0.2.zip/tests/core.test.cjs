const {test} = require('node:test');
const assert = require('node:assert/strict');
const C = require('../extension/core.js');
const valid = () => ({scope:'HK2', codes:'MATH101_01', available:'#open', registered:'#registered', action:'button', interval:30, duration:0, codeColumn:2, registeredColumn:2, seatColumn:0});
test('multiple codes retain priority and remove case-insensitive duplicates', () => {
  assert.deepEqual(C.parseCodes('math101_01\nPHY-02; MATH101_01,lab/03'), ['MATH101_01','PHY-02','LAB/03']);
});
test('reject empty input and selectors disguised as codes', () => {
  assert.throws(() => C.parseCodes(' , ; '));
  assert.throws(() => C.parseCodes('ABC"] button'));
});
test('normalize composed and decomposed Vietnamese', () => {
  assert.equal(C.normalize('  Đăng ký   học phần '), 'dang ky hoc phan');
});
test('capacity parser only accepts remaining integers; no guessed occupancy ratios', () => {
  assert.equal(C.seatCount(' 0 '), 0);
  assert.equal(C.seatCount('2'), 2);
  for (const text of ['30/40', '', '-1', 'còn 2', 'hết chỗ']) assert.equal(C.seatCount(text), null);
});
test('separate retryable full responses from academic blocks and expired login', () => {
  for (const t of ['Lớp đã đầy', 'Không còn chỗ', 'Hết sĩ số']) assert.equal(C.classifyNotice(t), 'full');
  for (const t of ['Trùng lịch học', 'Chưa đủ môn tiên quyết', 'Vượt số tín chỉ']) assert.equal(C.classifyNotice(t), 'blocked');
  assert.equal(C.classifyNotice('Phiên đăng nhập hết hạn'), 'auth');
  assert.equal(C.classifyNotice('Đăng ký thành công'), null); // Toast alone is not a receipt.
  assert.equal(C.classifyNotice('Lỗi mạng'), null);
});
test('require separate tables, mapped action, scope and bounded polling interval', () => {
  assert.equal(C.validateConfig(valid()).interval, 30);
  for (const changes of [{scope:''},{available:''},{action:''},{registered:'#open'},{interval:0},{interval:14},{interval:Infinity},{interval:3601},{codeColumn:0},{seatColumn:-1},{duration:NaN},{searchInput:'#input'},{startAt:'not-date'}]) {
    assert.throws(() => C.validateConfig({...valid(), ...changes}), JSON.stringify(changes));
  }
});
test('video four-field format groups alternate sections; LT and TH are separate requirements',()=>{
  const groups=C.parsePlan('MATH|GV A|Thứ 2|MATH_01\nMATH|GV B|Thứ 3|MATH_02\nMATH|*|*|MATH_TH1|TH');
  assert.equal(groups.length,2);assert.equal(groups[0].candidates.length,2);assert.equal(groups[1].kind,'TH');
  assert.deepEqual(C.flattenPlan(groups),['MATH_01','MATH_02','MATH_TH1']);
  assert.deepEqual(C.parsePlan(C.serializePlan(groups)),groups);
});
test('plain codes register all; greater-than syntax is a single priority group',()=>{
  assert.equal(C.parsePlan('MATH_01, MATH_02').length,2);
  const [g]=C.parsePlan('MATH_01 > MATH_02');
  assert.equal(g.candidates.length,2);
  assert.equal(C.groupState(g,{MATH_02:{state:'done'}}).code,'MATH_02');
  assert.equal(C.groupState(g,{MATH_01:{state:'full'}}).state,'waiting');
  assert.equal(C.groupState(g,{MATH_01:{state:'blocked'},MATH_02:{state:'blocked'}}).state,'blocked');
  assert.equal(C.groupState(g,{MATH_01:{state:'pending'}}).state,'uncertain');
});
test('reject cross-group duplicate codes and malformed priority imports',()=>{
  for(const input of ['MATH_01 > PHY_02\nPHY_02','MATH|a|b','MATH|a|b|MATH_01|XX','MATH_01 > MATH_02,PHY_03'])assert.throws(()=>C.parsePlan(input));
});
test('teacher and timetable wildcard filters normalize Vietnamese and HTML line breaks',()=>{
  assert.equal(C.matchesText('Nguyễn*Anh','TS. Nguyễn Văn Anh'),true);
  assert.equal(C.matchesText('Thứ 2<br/>Tiết 1-3','Thứ 2 Tiết 1-3'),true);
  assert.equal(C.matchesText('*','anything'),true);
  assert.equal(C.matchesText('Thứ 5','Thứ 2'),false);
});
test('switch plans preserve source and require specialized mapped buttons',()=>{
  const [g]=C.parsePlan('MATH|*|*|MATH_NEW|LT|MATH_OLD');
  assert.equal(g.switchFrom,'MATH_OLD');assert.equal(C.parsePlan(C.serializePlan([g]))[0].switchFrom,'MATH_OLD');
  assert.throws(()=>C.validateConfig({...valid(),codes:C.serializePlan([g])}));
  assert.doesNotThrow(()=>C.validateConfig({...valid(),codes:C.serializePlan([g]),switchAction:'button',switchTarget:'button'}));
  for(const codes of ['MATH|*|*|MATH_OLD|LT|MATH_OLD','MATH|*|*|MATH_NEW|LT|MATH_OLD\nMATH_OLD','MATH|*|*|MATH_NEW|LT|MATH_OLD\nMATH|*|*|MATH_ALT|LT'])assert.throws(()=>C.parsePlan(codes));
});
test('checkbox submit, program picker and parent-course mapping must be complete',()=>{
  for(const changes of [{actionKind:'checkbox'},{programValue:'ABC'},{registrationMode:'unknown'},{courses:'#courses'},{courses:'#courses',courseAction:'button'}])assert.throws(()=>C.validateConfig({...valid(),...changes}));
  assert.doesNotThrow(()=>C.validateConfig({...valid(),actionKind:'checkbox',batchSubmit:'#submit'}));
});
