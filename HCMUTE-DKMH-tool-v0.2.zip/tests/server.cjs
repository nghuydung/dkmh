// Local simulation only. Bind loopback; never expose the user's project on the LAN.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const allowed = new Map([
  ['/tests/fixture.html', ['tests/fixture.html','text/html; charset=utf-8']],
  ['/tests/fixture.js', ['tests/fixture.js','text/javascript; charset=utf-8']],
  ['/extension/core.js', ['extension/core.js','text/javascript; charset=utf-8']],
  ['/extension/content.js', ['extension/content.js','text/javascript; charset=utf-8']]
]);
http.createServer((req,res) => {
  const file = allowed.get(new URL(req.url, 'http://127.0.0.1').pathname);
  if (!file) {res.writeHead(404);res.end('Not found');return;}
  res.writeHead(200, {'Content-Type':file[1], 'Cache-Control':'no-store'});
  fs.createReadStream(path.join(root,file[0])).pipe(res);
}).listen(8765,'127.0.0.1', () => console.log('Simulation: http://127.0.0.1:8765/tests/fixture.html'));
