(function (root) {
  'use strict';
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').replace(/\s+/g, ' ').trim().toLowerCase();
  const codeKey = value => String(value ?? '').trim().toUpperCase();
  function parseCodes(text) {
    const values = String(text).split(/[\s,;]+/).filter(Boolean).map(codeKey);
    if (!values.length) throw new Error('Hãy nhập ít nhất một mã lớp học phần.');
    if (values.some(code => !/^[A-Z0-9_.\/-]{2,100}$/.test(code))) throw new Error('Mã lớp chỉ được chứa chữ, số, dấu . _ / -; mỗi mã một dòng.');
    return [...new Set(values)];
  }
  function seatCount(text) {
    // Only a user-mapped REMAINING seats column; never interpret Giới hạn as remaining.
    const n = String(text ?? '').trim();
    return /^\d+$/.test(n) ? Number(n) : null;
  }
  function classifyNotice(text) {
    const n = normalize(text);
    if (/het cho|het si so|da day|du si so|du so luong|khong con cho|lop day/.test(n)) return 'full';
    if (/trung lich|tien quyet|vuot.{0,30}tin chi|khong du dieu kien|hoc truoc/.test(n)) return 'blocked';
    if (/phien.{0,20}het han|dang nhap lai|chua dang nhap/.test(n)) return 'auth';
    return null;
  }
  function parsePlan(text) {
    const groups = [], grouped = new Map(), used = new Map();
    function add(group, candidate) {
      parseCodes(candidate.code);
      candidate.code = codeKey(candidate.code);
      const prior = used.get(candidate.code);
      if (prior && prior !== group.id) throw new Error(`Mã ${candidate.code} nằm trong hai nhóm yêu cầu khác nhau.`);
      if (!group.candidates.some(c => c.code === candidate.code)) group.candidates.push(candidate);
      used.set(candidate.code, group.id);
    }
    for (const raw of String(text).split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      if (line.includes('|')) {
        const parts = line.split('|').map(s => s.trim());
        if (parts.length < 4 || parts.length > 6) throw new Error('Định dạng: Mã môn|Giảng viên|Lịch học|Mã LHP|LT hoặc TH|Mã lớp cũ nếu chuyển nhóm.');
        const [course, teacher, schedule, code] = parts;
        if (parseCodes(course).length !== 1 || parseCodes(code).length !== 1) throw new Error('Mỗi dòng định dạng chỉ chứa một mã môn và một mã lớp.');
        const kind = codeKey(parts[4] || 'LT');
        if (!['LT','TH'].includes(kind)) throw new Error('Loại lớp phải là LT (lý thuyết) hoặc TH (thực hành).');
        const id = codeKey(course) + ':' + kind;
        const switchFrom=codeKey(parts[5] || '');
        if(switchFrom && (parseCodes(switchFrom).length!==1 || switchFrom===codeKey(code))) throw new Error('Mã lớp cũ cần là một mã và khác lớp đích.');
        if (!grouped.has(id)) { const g={id, course:codeKey(course), kind, candidates:[],...(switchFrom?{switchFrom}:{})}; grouped.set(id,g);groups.push(g); }
        if((grouped.get(id).switchFrom || '')!==switchFrom) throw new Error('Các lựa chọn cùng môn/loại phải dùng cùng mã lớp cũ khi chuyển nhóm.');
        add(grouped.get(id), {code, teacher, schedule});
      } else if (line.includes('>')) {
        const codes = line.split('>').map(s => s.trim());
        if (codes.some(s => parseCodes(s).length !== 1)) throw new Error('Mỗi lựa chọn trong nhóm ưu tiên phải là một mã lớp.');
        const id = 'CLASS:' + codeKey(codes[0]);
        let g=grouped.get(id);if(!g){g={id,course:'',kind:'',candidates:[]};grouped.set(id,g);groups.push(g);}
        for (const code of codes) add(g,{code,teacher:'',schedule:''});
      } else {
        for (const code of parseCodes(line)) {
          const id='CLASS:'+code;let g=grouped.get(id);
          if(!g){g={id,course:'',kind:'',candidates:[]};grouped.set(id,g);groups.push(g);}
          add(g,{code,teacher:'',schedule:''});
        }
      }
    }
    if (!groups.length) throw new Error('Hãy nhập ít nhất một mã lớp học phần.');
    const sources=new Set();
    for(const group of groups) if(group.switchFrom) {
      if(used.has(group.switchFrom) || sources.has(group.switchFrom)) throw new Error('Một lớp cũ không thể đồng thời là lớp đích hoặc nguồn của hai yêu cầu chuyển nhóm.');
      sources.add(group.switchFrom);
    }
    return groups;
  }
  const flattenPlan = groups => groups.flatMap(g => g.candidates.map(c => c.code));
  function serializePlan(groups) {
    return groups.flatMap(g => g.course ? g.candidates.map(c => `${g.course}|${c.teacher || ''}|${c.schedule || ''}|${c.code}|${g.kind || 'LT'}${g.switchFrom?'|'+g.switchFrom:''}`) : [g.candidates.map(c=>c.code).join(' > ')]).join('\n');
  }
  function groupState(group, ledger) {
    const done = group.candidates.find(c => ledger[c.code]?.state === 'done');
    if (done) return {state:'done', code:done.code};
    const unknown = group.candidates.find(c => ['pending','uncertain'].includes(ledger[c.code]?.state));
    if (unknown) return {state:'uncertain', code:unknown.code};
    if (group.candidates.every(c => ledger[c.code]?.state === 'blocked')) return {state:'blocked'};
    return {state:'waiting'};
  }
  function matchesText(pattern, value) {
    if (!String(pattern || '').trim() || pattern.trim() === '*') return true;
    const clean=s=>normalize(String(s).replace(/<br\s*\/?>/gi,' '));
    let rest=clean(value);
    for(const part of clean(pattern).split('*').filter(Boolean)) {const i=rest.indexOf(part);if(i<0)return false;rest=rest.slice(i+part.length);}
    return true;
  }
  function validateConfig(c) {
    const groups=parsePlan(c.codes);
    if (!String(c.scope ?? '').trim()) throw new Error('Nhập học kỳ / đợt đăng ký để tách nhật ký từng đợt.');
    if (!c.available || !c.registered || !c.action) throw new Error('Cần chọn bảng lớp mở, bảng đã đăng ký và nút đăng ký mẫu.');
    if (c.actionKind === 'checkbox' && !c.batchSubmit) throw new Error('Đã chọn checkbox: cần chọn thêm nút Đăng ký chung.');
    if(groups.some(g=>g.switchFrom) && (!c.switchAction || !c.switchTarget)) throw new Error('Chuyển nhóm cần ánh xạ nút Chuyển nhóm ở lớp cũ và nút chuyển vào lớp đích.');
    if(c.programValue && !c.programControl) throw new Error('Nhập chương trình đào tạo cần chọn bộ điều khiển chương trình trên trang.');
    if(c.registrationMode && !['current','plan','outside','program'].includes(c.registrationMode)) throw new Error('Kiểu đăng ký không hợp lệ.');
    if (c.available === c.registered) throw new Error('Bảng lớp mở và bảng đã đăng ký phải khác nhau.');
    if (!Number.isFinite(c.interval) || c.interval < 15 || c.interval > 3600) throw new Error('Chu kỳ kiểm tra phải từ 15 đến 3600 giây.');
    if (!Number.isInteger(c.codeColumn) || c.codeColumn < 1 || !Number.isInteger(c.registeredColumn) || c.registeredColumn < 1) throw new Error('Cột mã lớp phải là số nguyên từ 1.');
    if (!Number.isInteger(c.seatColumn) || c.seatColumn < 0) throw new Error('Cột còn chỗ phải là số nguyên từ 0.');
    if (!Number.isFinite(c.duration) || c.duration < 0) throw new Error('Giới hạn phút phải từ 0 trở lên.');
    if (Boolean(c.searchInput) !== Boolean(c.searchButton)) throw new Error('Nếu dùng tìm kiếm, cần chọn cả ô tìm và nút tìm.');
    if (Boolean(c.courses) !== Boolean(c.courseAction)) throw new Error('Mở môn trước khi chọn lớp cần cả bảng môn và nút mở lớp mẫu.');
    if (c.courses && groups.some(g=>!g.course)) throw new Error('Khi dùng bảng môn cha, mỗi lớp cần định dạng Mã môn|GV|Lịch|Mã LHP|LT/TH.');
    if (c.courses && (!Number.isInteger(c.courseColumn) || c.courseColumn < 1)) throw new Error('Cột mã môn phải từ 1.');
    if (c.startAt && !Number.isFinite(Date.parse(c.startAt + ':00+07:00'))) throw new Error('Giờ bắt đầu không hợp lệ.');
    return c;
  }
  const api = { normalize, codeKey, parseCodes, parsePlan, flattenPlan, serializePlan, groupState, matchesText, seatCount, classifyNotice, validateConfig };
  root.DKMHCore = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
