(() => {
  'use strict';
  if (document.getElementById('hcmute-dkmh-tool')) return;
  const C = globalThis.DKMHCore;
  const demo = location.hostname === '127.0.0.1' && location.pathname === '/tests/fixture.html';
  const host = document.createElement('div');
  host.id = 'hcmute-dkmh-tool';
  host.style.cssText = 'position:fixed;right:16px;top:16px;z-index:2147483647;font:14px system-ui';
  document.documentElement.append(host);
  const ui = host.attachShadow({ mode: 'open' });
  ui.innerHTML = `
    <style>
      :host{color-scheme:light}*{box-sizing:border-box}button,input,textarea{font:inherit}
      .panel{width:390px;max-width:calc(100vw - 32px);max-height:94vh;overflow:auto;background:#f6f8fc;border:1px solid #d7e0ec;border-radius:16px;box-shadow:0 16px 64px #102a4340;color:#152a42}
      header{display:flex;align-items:center;justify-content:space-between;background:#122c46;color:white;padding:15px 17px;position:sticky;top:0;z-index:2}
      header b{font-size:16px}header small{display:block;color:#a8c1d8;margin-top:3px}header button{background:transparent;color:white;border:1px solid #65819b;padding:3px 10px}
      main{padding:16px}label{display:block;font-size:12px;font-weight:650;margin:11px 0 5px}input,textarea{width:100%;border:1px solid #b9c9db;border-radius:7px;padding:8px;background:white;color:#152a42}textarea{resize:vertical;line-height:1.5}
      button{border:1px solid #b9c9db;border-radius:7px;padding:8px 10px;background:white;color:#173650;cursor:pointer}button:hover{filter:brightness(.95)}button:disabled{opacity:.5;cursor:default}
      .row{display:flex;gap:8px}.row>*{flex:1;min-width:0}.primary{background:#087f76;border-color:#087f76;color:white;font-weight:700}.danger{color:#b32935;border-color:#df9fa6}.muted{font-size:12px;color:#587086;line-height:1.5}details{margin-top:14px;border-top:1px solid #d7e0ec;padding-top:12px}summary{cursor:pointer;font-weight:650;font-size:13px}
      .pick{display:flex;align-items:center;gap:6px;margin-top:8px}.pick button{flex:1;text-align:left;font-size:12px}.pick span{width:20px;color:#087f76}.status{padding:9px 11px;background:#e8eff7;border-radius:7px;font-size:12px;line-height:1.5;margin:12px 0;white-space:pre-wrap}
      pre{font:11px/1.6 ui-monospace,monospace;white-space:pre-wrap;max-height:175px;overflow:auto;margin:10px 0 0;padding:10px;border-radius:7px;background:#13283e;color:#d9e8f5}.tiny{font-size:11px}#preview{white-space:pre-wrap;font-size:12px;line-height:1.6;margin:8px 0}.hidden{display:none}#expand{background:#122c46;color:white;border-radius:22px;box-shadow:0 6px 24px #13283e40;padding:10px 16px}
      .panel{width:520px}select{font:inherit;width:100%;padding:8px;border:1px solid #b9c9db;border-radius:7px;background:white;color:#152a42}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:12px}.stats div{background:#e8eff7;border-radius:8px;padding:8px;font-size:11px}.stats b{display:block;font-size:20px}.queue-item{padding:10px;border:1px solid #d7e0ec;background:white;border-radius:8px;margin:6px 0;font-size:12px}.queue-item strong{display:block}.queue-item .tools{display:flex;gap:4px;margin-top:6px}.queue-item button{font-size:11px;padding:3px 8px}.catalog-wrap{overflow:auto;max-height:260px;margin:8px 0}.catalog{border-collapse:collapse;font-size:11px;width:100%;background:white}.catalog td,.catalog th{border:1px solid #d7e0ec;padding:6px;text-align:left;min-width:65px}.catalog input{width:auto}.toolbar{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0}.toolbar button{font-size:12px}.catalog-title{font-size:12px;margin:10px 0 3px;color:#087f76}#queue{max-height:300px;overflow:auto}
    </style>
    <button id="expand" class="hidden">DKMH • Mở tool</button>
    <section class="panel"><header><div><b>Đăng ký học phần</b><small>HCMUTE · hàng loạt & chờ chỗ</small></div><button id="minimize" title="Thu gọn">−</button></header>
    <main>
      <div class="muted">Dùng phiên đăng nhập hiện tại. Giữ tab mở, máy thức. ${demo ? '<b>TRANG MÔ PHỎNG</b>' : ''}</div>
      <label for="scope">Học kỳ / đợt đăng ký</label><input id="scope" placeholder="VD: HK2 2026–2027 · đợt 1">
      <label for="programValue">Chương trình đào tạo (để trống = giữ nguyên)</label><input id="programValue" placeholder="Tên / mã hiển thị chính xác trên trang trường">
      <label for="registrationMode">Kiểu đăng ký trên trang trường</label><select id="registrationMode"><option value="current">Giữ kiểu đang chọn</option><option value="plan">Đăng ký theo kế hoạch</option><option value="outside">Đăng ký ngoài kế hoạch</option><option value="program">Đăng ký ngoài chương trình</option></select>
      <label for="codes">Danh sách môn / lớp ưu tiên</label><textarea id="codes" rows="4" placeholder="LHP_01 > LHP_02 (chọn một trong hai)&#10;Hoặc: Mã môn|Giảng viên|Lịch học|Mã LHP|LT/TH"></textarea>
      <div class="muted">Một mã mỗi dòng = đăng ký tất cả. Dùng <b>A &gt; B</b> để chọn một lớp, ưu tiên A rồi B. Định dạng giống video: <b>Mã môn|Giảng viên|Lịch học|Mã LHP</b>; thêm <b>|TH</b> cho thực hành. Các dòng cùng môn và loại là lựa chọn thay thế, không đăng ký hết.</div>
      <div class="toolbar"><button id="loadPlan">Cập nhật danh sách</button><button id="exportPlan">Lưu kế hoạch</button><button id="importPlan">Nạp kế hoạch</button><button id="exportResults">Xuất kết quả CSV</button><input id="planFile" type="file" accept=".json,.txt" hidden></div>
      <details id="catalogDetails"><summary>Chọn môn & lớp bằng bảng như video</summary>
        <div class="muted">Đọc dữ liệu đang hiển thị trên trang trường. Chọn môn để mở bảng lớp (nếu đã thiết lập bảng môn cha), rồi chọn các lớp ưu tiên.</div>
        <div class="row"><div><label for="catalogCourse">Mã môn của bảng lớp này</label><input id="catalogCourse" placeholder="VD: LLCT120205"></div><div><label for="catalogKind">Loại lớp</label><select id="catalogKind"><option value="LT">Lý thuyết</option><option value="TH">Thực hành</option></select></div></div>
        <label for="catalogFilter">Lọc mã, giảng viên, lịch học</label><input id="catalogFilter" placeholder="Nhập để lọc bảng">
        <div class="toolbar"><button id="scanCatalog">Đọc bảng lớp đang mở</button><button id="scanCourses">Đọc bảng môn cha</button><button id="addCatalog">Thêm lớp đã chọn vào kế hoạch</button></div><div id="catalog"></div>
      </details>
      <div class="row"><div><label for="interval">Kiểm tra lại (giây)</label><input id="interval" type="number" min="15" max="3600" value="30"></div><div><label for="duration">Dừng sau (phút, 0 = chờ mãi)</label><input id="duration" type="number" min="0" value="0"></div></div>
      <label for="startAt">Bắt đầu lúc · giờ Việt Nam (bỏ trống = ngay)</label><input id="startAt" type="datetime-local">
      <details id="mapping"><summary>Thiết lập giao diện · chọn một lần khi có bảng lớp</summary>
        <p class="muted">Bấm nút chọn rồi bấm thành phần tương ứng trên trang. Esc để hủy. Hai bảng phải hiển thị đầy đủ mã cần kiểm tra; tool chỉ đọc phần đang có trong DOM.</p>
        <div class="pick"><button data-pick="programControl">Chọn bộ chọn chương trình đào tạo</button><span id="mark-programControl">○</span></div>
        <div class="pick"><button data-pick="available">1. Chọn bảng lớp đang mở</button><span id="mark-available">○</span></div>
        <div class="pick"><button data-pick="registered">2. Chọn bảng đã đăng ký</button><span id="mark-registered">○</span></div>
        <div class="pick"><button data-pick="action">3. Chọn nút Đăng ký trong một dòng lớp</button><span id="mark-action">○</span></div>
        <div class="pick"><button data-pick="batchSubmit">Chọn nút Đăng ký chung (nếu dòng dùng checkbox)</button><span id="mark-batchSubmit">○</span></div>
        <div class="row"><div><label for="codeColumn">Cột mã ở bảng lớp (từ 1)</label><input id="codeColumn" type="number" min="1" value="2"></div><div><label for="registeredColumn">Cột mã ở bảng đã đăng ký</label><input id="registeredColumn" type="number" min="1" value="2"></div></div>
        <label for="seatColumn">Cột số chỗ CÒN LẠI (0 = không dùng)</label><input id="seatColumn" type="number" min="0" value="0"><div class="muted">Chỉ chọn cột số chỗ còn lại. Không chọn cột “Giới hạn” hoặc sĩ số tối đa.</div>
        <div class="pick"><button data-pick="refresh">4. Chọn nút tải lại danh sách</button><span id="mark-refresh">tự</span></div>
        <details><summary>Tìm từng mã (tùy chọn)</summary><p class="muted">Chỉ chọn nếu trang ĐĂNG KÝ có ô tìm hỗ trợ mã LHP. Không dùng ô tra cứu mã môn. Bộ lọc phải ở chế độ tìm mã lớp.</p><div class="pick"><button data-pick="searchInput">Chọn ô nhập mã LHP</button><span id="mark-searchInput">○</span></div><div class="pick"><button data-pick="searchButton">Chọn nút tìm</button><span id="mark-searchButton">○</span></div><button id="clearSearch">Bỏ tìm từng mã</button></details>
        <details><summary>Mở môn → chọn lớp LT/TH (tùy chọn)</summary><p class="muted">Dùng nếu phải mở từng môn để thấy các lớp. Chọn bảng môn cha và nút mở danh sách lớp trong một dòng. Mỗi dòng kế hoạch phải có mã môn.</p><div class="pick"><button data-pick="courses">Chọn bảng môn cha</button><span id="mark-courses">○</span></div><div class="pick"><button data-pick="courseAction">Chọn nút mở lớp của môn</button><span id="mark-courseAction">○</span></div><label for="courseColumn">Cột mã môn ở bảng môn cha (từ 1)</label><input id="courseColumn" type="number" min="1" value="2"><button id="clearCourses">Bỏ bước mở môn cha</button></details>
        <details><summary>Chuyển nhóm qua chức năng của trường (tùy chọn)</summary><p class="muted">Thêm cột thứ 6 là mã lớp cũ: Mã môn|*|*|Lớp mới|LT|Lớp cũ. Chỉ dùng khi trang có nút Chuyển nhóm chuyên biệt. Hai nút mẫu phải là nút chuyển nhóm, không phải Hủy hay Đăng ký thường.</p><div class="pick"><button data-pick="switchAction">Chọn nút Chuyển nhóm ở dòng đã đăng ký</button><span id="mark-switchAction">○</span></div><div class="pick"><button data-pick="switchTarget">Chọn nút chuyển vào lớp đích ở bảng lớp</button><span id="mark-switchTarget">○</span></div></details>
        <p class="muted">Hỗ trợ nút Đăng ký trực tiếp hoặc checkbox + nút Đăng ký chung. Chuyển nhóm chỉ chạy khi có mã lớp cũ và nút chuyển nhóm đã ánh xạ. Không tự hủy lớp.</p>
      </details>
      <div id="status" class="status" role="status">Sẵn sàng thiết lập. Chưa gửi đăng ký nào.</div>
      <div class="row"><button id="previewButton">Xem trước</button><button id="start" class="primary">Bắt đầu tự đăng ký</button><button id="stop" class="danger" disabled>Dừng</button></div>
      <div id="stats" class="stats"></div><div id="queue" aria-label="Theo dõi từng môn"></div>
      <div id="preview"></div><pre id="log" aria-label="Nhật ký hoạt động">Chưa chạy.</pre>
      <details><summary>Nhật ký gửi & khôi phục</summary><p class="muted">Lưu trạng thái gửi ngay trước khi bấm để tránh gửi lặp khi tải lại trang. Nếu “chưa rõ kết quả”, hãy kiểm tra bảng đã đăng ký. Tool không tự chạy lại sau khi tải trang.</p><button id="reconcile">Đối soát bảng đã đăng ký</button><button id="reset" class="danger">Xóa nhật ký đợt này…</button></details>
      <p class="muted tiny">Không lưu mật khẩu/cookie. Không tự bỏ học phần. Lớp đầy sẽ chờ vòng sau; lỗi không rõ kết quả sẽ dừng.</p>
    </main></section>`;
  const $ = id => ui.getElementById(id);
  const defaults = { scope: '', codes: '', interval: 30, duration: 0, startAt: '', codeColumn: 2, registeredColumn: 2, seatColumn: 0, courseColumn:2, registrationMode:'current',programValue:'' };
  let config = { ...defaults }, running = false, controller, picking = null, messages = [], catalogRows=[], catalogSelection=new Set(), attempts=0;
  const fields = Object.keys(defaults);
  const storage = {
    async get(key) {
      if (demo) return JSON.parse(localStorage.getItem('dkmh-demo:' + key) || 'null');
      const values = await chrome.storage.local.get(key);
      return values[key];
    },
    async set(key, value) {
      if (demo) { localStorage.setItem('dkmh-demo:' + key, JSON.stringify(value)); return; }
      await chrome.storage.local.set({ [key]: value });
    }
  };
  function log(text) {
    messages.push(`[${new Date().toLocaleTimeString('vi-VN', {timeZone:'Asia/Ho_Chi_Minh'})}] ${text}`);
    messages = messages.slice(-150);
    $('log').textContent = messages.join('\n');
    $('log').scrollTop = $('log').scrollHeight;
  }
  const status = text => { $('status').textContent = text; };
  function readConfig() {
    const c = { ...config };
    for (const f of fields) c[f] = ['interval','duration','codeColumn','registeredColumn','seatColumn','courseColumn'].includes(f) ? Number($(f).value) : $(f).value.trim();
    return c;
  }
  async function save() { config = readConfig(); await storage.set('settings', config); }
  function marks() {
    for (const key of ['available','registered','action','refresh','searchInput','searchButton','batchSubmit','courses','courseAction','switchAction','switchTarget','programControl']) $('mark-' + key).textContent = config[key] ? '✓' : key === 'refresh' ? 'tự' : '○';
  }
  function visible(el) { return Boolean(el?.isConnected && el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).display !== 'none'); }
  function unique(selector, required = true) {
    if (!selector) { if (required) throw new Error('Chưa chọn thành phần trên trang.'); return null; }
    const nodes = [...document.querySelectorAll(selector)].filter(visible);
    if (nodes.length !== 1) throw new Error('Thành phần đã chọn bị mất hoặc không duy nhất. Hãy chọn lại giao diện.');
    return nodes[0];
  }
  function label(el) { return C.normalize([el.textContent, el.getAttribute('aria-label'), el.getAttribute('title')].filter(Boolean).join(' ')); }
  function headers(table) { return [...table.querySelectorAll('thead th, thead td')].map(e => C.normalize(e.textContent)); }
  function tableFor(c, key) {
    const table = unique(c[key]);
    if (!table.matches('table')) throw new Error('Bảng đã chọn không còn là bảng dữ liệu.');
    if (JSON.stringify(headers(table)) !== JSON.stringify(c[key + 'Headers'])) throw new Error('Tiêu đề bảng đã thay đổi. Hãy chọn lại giao diện.');
    return table;
  }
  function matchingRows(table, code, column) {
    return [...table.querySelectorAll('tbody tr')].filter(row => visible(row) && C.codeKey(row.cells[column - 1]?.textContent) === C.codeKey(code));
  }
  function registered(c, code) { return matchingRows(tableFor(c, 'registered'), code, c.registeredColumn).length > 0; }
  function rowFor(c, code) {
    const rows = matchingRows(tableFor(c, 'available'), code, c.codeColumn);
    if (rows.length > 1) throw new Error(`Có nhiều dòng cùng mã ${code}; cần lọc rõ lớp/nhóm trước.`);
    return rows[0];
  }
  function actionFor(c, row) {
    const buttons = [...row.querySelectorAll(c.action)].filter(visible);
    if (buttons.length !== 1) throw new Error('Không xác định duy nhất nút đăng ký trong dòng. Hãy chọn lại nút mẫu.');
    const el = buttons[0];
    const actionLabel=c.actionLabel?.includes('{code}') ? label(el).split(C.normalize(row.cells[c.codeColumn-1]?.textContent)).join('{code}') : label(el);
    if (actionLabel !== c.actionLabel || /\b(?:huy|xoa|rut|cancel|delete)\b/.test(label(el))) throw new Error('Nhãn nút thay đổi hoặc là nút hủy. Dừng để kiểm tra.');
    if (c.actionKind === 'checkbox' && !el.matches('input[type="checkbox"]')) throw new Error('Checkbox mẫu đã thay đổi.');
    return el;
  }
  function full(c, row, button) {
    if (button.disabled || button.getAttribute('aria-disabled') === 'true') return 'nút chưa cho phép đăng ký';
    if (c.seatColumn > 0) {
      const count = C.seatCount(row.cells[c.seatColumn - 1]?.textContent);
      if (count === null) throw new Error('Cột còn chỗ không phải số nguyên. Cần sửa cấu hình.');
      if (count === 0) return 'hết chỗ';
    }
    if (C.classifyNotice(row.textContent) === 'full') return 'hết chỗ';
    return null;
  }
  function path(el, ancestor = document.body) {
    const parts = [];
    for (let node = el; node && node !== ancestor; node = node.parentElement) {
      if (node.id && document.querySelectorAll('#' + CSS.escape(node.id)).length === 1 && ancestor === document.body) {
        parts.unshift('#' + CSS.escape(node.id)); return parts.join(' > ');
      }
      const siblings = [...node.parentElement.children].filter(e => e.tagName === node.tagName);
      parts.unshift(node.tagName.toLowerCase() + ':nth-of-type(' + (siblings.indexOf(node) + 1) + ')');
    }
    return (ancestor === document.body ? 'body > ' : '') + parts.join(' > ');
  }
  function cancelPick() {
    if (!picking) return;
    document.removeEventListener('click', picking.click, true);
    document.removeEventListener('keydown', picking.key, true);
    picking = null;
  }
  function pick(kind) {
    if (running) return;
    cancelPick();
    status('Đang chọn: ' + kind + '. Bấm thành phần trên trang; Esc để hủy.');
    const click = async event => {
      if (event.composedPath().includes(host)) return;
      event.preventDefault(); event.stopImmediatePropagation();
      try {
        const target = event.target;
        if(kind==='programControl') {
          const control=target.closest('select,[aria-haspopup="listbox"]');
          if(!control)throw new Error('Chọn bộ chọn chương trình đào tạo trên trang.');
          config[kind]=path(control);
        } else if (kind === 'available' || kind === 'registered' || kind === 'courses') {
          const table = target.closest('table');
          if (!table) throw new Error('Hãy bấm trong bảng dữ liệu HTML.');
          const other = kind === 'available' ? 'registered' : 'available';
          if (kind !== 'courses' && config[other] && unique(config[other]) === table) throw new Error('Cần chọn hai bảng khác nhau.');
          config[kind] = path(table); config[kind + 'Headers'] = headers(table);
        } else if (['action','courseAction','switchAction','switchTarget'].includes(kind)) {
          const button = target.closest('button, a, [role="button"], input[type="button"], input[type="submit"], input[type="checkbox"]');
          const row = button?.closest('tbody tr');
          const tableKey=kind==='courseAction'?'courses':kind==='switchAction'?'registered':'available';
          if (!button || !row || !config[tableKey] || row.closest('table') !== tableFor(config, tableKey)) throw new Error('Chọn nút trong bảng tương ứng đã ánh xạ trước.');
          if (/\b(?:huy|xoa|rut|cancel|delete)\b/.test(label(button))) throw new Error('Đây là nút hủy/xóa; không dùng để đăng ký.');
          if(kind!=='action' && button.matches('input[type="checkbox"]'))throw new Error('Bước này cần nút trực tiếp, không phải checkbox.');
          if(kind.startsWith('switch') && !/chuyen|c\.\s*nhom/.test(label(button)))throw new Error('Nút phải có nhãn Chuyển nhóm / Chuyển / C.Nhóm.');
          config[kind] = path(button, row); config[kind+'Label'] = label(button);
          if(kind==='action') {const code=C.normalize(row.cells[readConfig().codeColumn-1]?.textContent);if(code)config.actionLabel=config.actionLabel.split(code).join('{code}');}
          if(kind==='action') config.actionKind=button.matches('input[type="checkbox"]')?'checkbox':'button';
        } else {
          const el = kind === 'searchInput' ? target.closest('input[type="text"], input:not([type]), input[type="search"]') : target.closest('button, a, [role="button"]');
          if (!el) throw new Error('Không đúng loại thành phần cần chọn.');
          if (kind !== 'searchInput' && /\b(?:huy|xoa|rut|cancel|delete)\b/.test(label(el))) throw new Error('Nút này không phù hợp.');
          if (kind !== 'searchInput' && kind !== 'batchSubmit' && /dang ky/.test(label(el))) throw new Error('Không chọn nút đăng ký để tải lại/tìm kiếm.');
          config[kind] = path(el); config[kind + 'Label'] = label(el);
        }
        cancelPick(); marks(); await save(); status('Đã lưu lựa chọn. Bấm Xem trước để kiểm tra.');
      } catch (e) { status(e.message); }
    };
    const key = e => { if (e.key === 'Escape') { cancelPick(); status('Đã hủy chọn.'); } };
    picking = { click, key };
    document.addEventListener('click', click, true); document.addEventListener('keydown', key, true);
  }
  function ensurePage() {
    if (!demo && location.pathname !== '/Student/RegistScheduleUnit') throw new Error('Mở trang Đăng ký học phần trước khi chạy.');
    if (document.querySelector('input[type="password"]')) throw new Error('Phiên đăng nhập đã hết. Hãy tự đăng nhập rồi chạy lại.');
    if ([...document.querySelectorAll('iframe[src*="captcha"], [id*="captcha"], [class*="captcha"]')].some(visible)) throw new Error('Trang yêu cầu CAPTCHA; hãy tự xử lý trước khi chạy lại.');
    const dialogs=[...document.querySelectorAll('[role="dialog"], [aria-modal="true"]')].filter(visible);
    if (dialogs.some(dialog => {
      // A configured class-list dialog is navigational, not a confirmation dialog.
      if ((!config.courses && !config.switchAction) || !config.available) return true;
      const tables=[...dialog.querySelectorAll('table')].filter(t=>t.matches(config.available));
      return tables.length!==1 || JSON.stringify(headers(tables[0]))!==JSON.stringify(config.availableHeaders);
    })) throw new Error('Trang đang mở hộp thoại; cần xử lý thủ công trước khi chạy tiếp.');
  }
  function checkpoint(signal) { if (signal.aborted) throw new DOMException('Đã dừng', 'AbortError'); ensurePage(); }
  function sleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) return reject(new DOMException('Đã dừng', 'AbortError'));
      const done = () => { signal.removeEventListener('abort', abort); resolve(); };
      const timer = setTimeout(done, ms);
      const abort = () => { clearTimeout(timer); signal.removeEventListener('abort', abort); reject(new DOMException('Đã dừng', 'AbortError')); };
      signal.addEventListener('abort', abort, { once: true });
    });
  }
  function namedControl(c, key, fallbackName) {
    let el;
    if (c[key]) {
      el = unique(c[key]);
      if (label(el) !== c[key + 'Label']) throw new Error('Nhãn nút tải lại/tìm kiếm đã đổi. Chọn lại giao diện.');
    } else {
      const found = [...document.querySelectorAll('button')].filter(e => visible(e) && C.normalize(e.textContent) === fallbackName);
      if (found.length !== 1) throw new Error('Cần chọn nút tải lại danh sách ở bước 4.');
      el = found[0];
    }
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') throw new Error('Nút tải lại/tìm đang bị khóa.');
    return el;
  }
  async function settle(signal) {
    // Allow React to apply a response; do not require network hooks or inspect credentials.
    await sleep(1500, signal);
    const until = Date.now() + 15000;
    while ([...document.querySelectorAll('[role="progressbar"], [aria-busy="true"]')].some(visible)) {
      checkpoint(signal);
      if (Date.now() > until) throw new Error('Danh sách tải quá lâu. Chưa gửi đăng ký; hãy kiểm tra kết nối.');
      await sleep(250, signal);
    }
    checkpoint(signal);
  }
  async function refresh(c, signal) {
    checkpoint(signal);
    await selectProgram(c,signal);
    await selectMode(c, signal);
    namedControl(c, 'refresh', 'lam moi').click();
    await settle(signal);
    if(c.courses)tableFor(c,'courses');
    else if(!C.parsePlan(c.codes).every(g=>g.switchFrom))tableFor(c,'available');
    tableFor(c, 'registered');
  }
  async function selectProgram(c,signal) {
    if(!c.programValue)return;
    const control=unique(c.programControl),value=C.normalize(c.programValue);
    if(control.matches('select')) {
      const options=[...control.options].filter(o=>C.normalize(o.textContent)===value);
      if(options.length!==1)throw new Error('Không tìm thấy chương trình đào tạo theo tên hiển thị.');
      if(control.value!==options[0].value){checkpoint(signal);Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set.call(control,options[0].value);control.dispatchEvent(new Event('change',{bubbles:true}));await settle(signal);}
    }else{
      if(C.normalize(control.textContent)===value)return;
      checkpoint(signal);control.click();await sleep(150,signal);
      const options=[...document.querySelectorAll('[role="option"]')].filter(el=>visible(el)&&C.normalize(el.textContent)===value);
      if(options.length!==1)throw new Error('Không tìm thấy duy nhất chương trình đào tạo trong danh sách.');
      options[0].click();await settle(signal);
    }
  }
  async function selectMode(c, signal) {
    if (!c.registrationMode || c.registrationMode==='current') return;
    const names={plan:'dang ky theo ke hoach',outside:'dang ky ngoai ke hoach',program:'dang ky ngoai chuong trinh'};
    const name=names[c.registrationMode];
    const radios=[...document.querySelectorAll('input[type="radio"]')].filter(el=>{
      const parent=el.closest('label');
      const linked=el.id ? document.querySelector('label[for="'+CSS.escape(el.id)+'"]') : null;
      return visible(parent || el) && C.normalize(parent?.textContent || linked?.textContent || el.getAttribute('aria-label'))===name;
    });
    if (radios.length!==1) throw new Error('Không tìm thấy duy nhất kiểu đăng ký đã chọn. Hãy chọn trên trang rồi đặt tool về Giữ kiểu đang chọn.');
    if (!radios[0].checked) {checkpoint(signal);radios[0].click();await settle(signal);}
  }
  async function openCourse(c, group, signal) {
    if (!c.courses) return;
    checkpoint(signal);
    const rows=matchingRows(tableFor(c,'courses'),group.course,c.courseColumn);
    if(rows.length!==1) throw new Error('Không tìm thấy duy nhất môn cha '+group.course+'. Hãy hiển thị/lọc đúng bảng môn.');
    const buttons=[...rows[0].querySelectorAll(c.courseAction)].filter(visible);
    if(buttons.length!==1 || label(buttons[0])!==c.courseActionLabel || /\b(?:huy|xoa|rut)\b/.test(label(buttons[0]))) throw new Error('Nút mở danh sách lớp thay đổi.');
    buttons[0].click(); await settle(signal); tableFor(c,'available');
  }
  async function openSwitch(c,group,signal) {
    checkpoint(signal);
    const rows=matchingRows(tableFor(c,'registered'),group.switchFrom,c.registeredColumn);
    if(rows.length!==1)throw new Error('Không tìm thấy duy nhất lớp cũ '+group.switchFrom+' để chuyển nhóm.');
    const buttons=[...rows[0].querySelectorAll(c.switchAction)].filter(visible);
    if(buttons.length!==1 || label(buttons[0])!==c.switchActionLabel || !/chuyen|c\.\s*nhom/.test(label(buttons[0])) || buttons[0].disabled)throw new Error('Nút chuyển nhóm ở lớp cũ không hợp lệ.');
    buttons[0].click();await settle(signal);tableFor(c,'available');
  }
  function candidateMatches(c, row, candidate) {
    const h=headers(tableFor(c,'available'));
    for(const [field,re] of [['teacher',/giang vien/],['schedule',/lich hoc|thong tin/]]) {
      if(!candidate?.[field] || candidate[field]==='*') continue;
      const index=h.findIndex(s=>re.test(s));
      if(index<0) throw new Error('Không tìm thấy cột '+(field==='teacher'?'giảng viên':'lịch học')+' để kiểm tra điều kiện đã nhập. Dùng * nếu chỉ cần đối chiếu mã LHP.');
      if(!C.matchesText(candidate[field],row.cells[index]?.textContent)) return false;
    }
    return true;
  }
  async function search(c, code, signal) {
    if (!c.searchInput) return;
    checkpoint(signal);
    const input = unique(c.searchInput);
    if (!input.matches('input') || input.type === 'password') throw new Error('Ô tìm không hợp lệ.');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, code);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(100, signal); checkpoint(signal);
    namedControl(c, 'searchButton').click(); await settle(signal);
  }
  const ledgerKey = c => 'ledger:' + c.scope.trim();
  async function getLedger(c) { return (await storage.get(ledgerKey(c))) || {}; }
  async function persist(c, ledger) { await storage.set(ledgerKey(c), ledger); updateDashboard(c,ledger); }
  function fulfilled(c,group,code) { return registered(c,code) && (!group.switchFrom || !registered(c,group.switchFrom)); }
  async function reconcile(c) {
    const ledger = await getLedger(c);
    for (const group of C.parsePlan(c.codes)) for(const candidate of group.candidates) {
      if (fulfilled(c,group,candidate.code)) ledger[candidate.code] = { state:'done', at:new Date().toISOString() };
      else if(group.switchFrom && registered(c,candidate.code)) throw new Error('Cả lớp cũ và lớp đích đều có trong bảng. Cần kiểm tra kết quả chuyển nhóm thủ công.');
    }
    await persist(c, ledger); return ledger;
  }
  function preview(c) {
    C.validateConfig(c); ensurePage();
    tableFor(c,'registered');
    if(c.courses) tableFor(c,'courses');
    else if (!C.parsePlan(c.codes).every(g=>g.switchFrom) && tableFor(c, 'available') === tableFor(c, 'registered')) throw new Error('Hai bảng đang trỏ cùng một thành phần.');
    return C.parsePlan(c.codes).map(group => {
      const done=group.candidates.find(candidate=>fulfilled(c,group,candidate.code));
      if(done) return `${group.course || group.id} · đã đăng ký ${done.code}; bỏ các lựa chọn khác`;
      return group.candidates.map(candidate=>{
        const code=candidate.code;
        if(group.switchFrom) return `${group.switchFrom} → ${code} · chuyển nhóm qua nút chuyên biệt của trường`;
        if(c.courses) return `${code} · sẽ mở môn ${group.course} để chọn lớp ${group.kind}`;
        const row = rowFor(c, code);
        if (!row) return `${code} · chưa có trong bảng đang hiển thị`;
        if(!candidateMatches(c,row,candidate)) return `${code} · không khớp giảng viên/lịch đã nhập`;
        const b = actionFor(c, row), reason = full(c, row, b);
        return `${code} · ${reason ? 'chờ: ' + reason : 'sẵn sàng bấm Đăng ký'}`;
      }).join('\n');
    }).join('\n');
  }
  function checkSelection(c,row) {
    if(c.actionKind!=='checkbox') return;
    const selected=[...tableFor(c,'available').querySelectorAll('input[type="checkbox"]:checked')];
    if(selected.some(el=>el.closest('tr')!==row)) throw new Error('Bảng đang chọn checkbox của lớp khác. Bỏ chọn thủ công trước khi chạy để không gửi thừa lớp.');
  }
  function clearOwnSelection(c,code) {
    if(c.actionKind!=='checkbox') return;
    // The result may have closed the class view. Only clear an identifiable surviving row.
    const tables=[...document.querySelectorAll(c.available)].filter(visible);
    if(tables.length!==1)return;
    const rows=matchingRows(tables[0],code,c.codeColumn);
    if(rows.length!==1)return;
    const controls=rows[0].querySelectorAll(c.action);
    if(controls.length===1 && controls[0].matches('input[type="checkbox"]') && controls[0].checked && !controls[0].disabled) controls[0].click();
  }
  async function submit(c, code, signal, ledger, candidate,group={}) {
    checkpoint(signal);
    // Re-read immediately before sending: never click a row retained from a previous refresh.
    if (fulfilled(c,group,code)) return 'done';
    if(group.switchFrom && registered(c,code))throw new Error('Cả lớp cũ và lớp mới đang có; cần kiểm tra thủ công.');
    const row = rowFor(c, code);
    if (!row) return 'missing';
    if(!candidateMatches(c,row,candidate)) return 'mismatch';
    const button = actionFor(c, row);
    if (full(c, row, button)) return 'full';
    checkSelection(c,row);
    const notices = new Set();
    const noticeSelector = '[role="alert"], .MuiAlert-root, .Toastify__toast, .notistack-SnackbarContent';
    const initialNotices = new Set([...document.querySelectorAll(noticeSelector)].filter(visible).map(el => el.textContent));
    const observer = new MutationObserver(mutations => {
      for (const mutation of mutations) {
        if (host.contains(mutation.target) || mutation.target === host) continue;
        for (const el of document.querySelectorAll(noticeSelector)) if (visible(el) && !initialNotices.has(el.textContent)) notices.add(el.textContent);
      }
    });
    observer.observe(document.body, { subtree: true, childList: true, characterData: true });
    let sent = false;
    try {
      ledger[code] = {state:'pending', at:new Date().toISOString()};
      await persist(c, ledger); // Failure to journal must prevent the click.
      checkpoint(signal);
      // Storage writes yield to React. Revalidate both row identity and state after the await.
      if (fulfilled(c,group,code)) return 'done';
      const currentRow = rowFor(c, code);
      if (!currentRow) return 'missing';
      if(!candidateMatches(c,currentRow,candidate)) return 'mismatch';
      const currentButton = actionFor(c, currentRow);
      if (full(c, currentRow, currentButton)) return 'full';
      checkSelection(c,currentRow);
      if(c.actionKind==='checkbox') {
        if(!currentButton.checked) currentButton.click();
        await sleep(100,signal);checkpoint(signal);
        if(!currentButton.isConnected || !currentButton.checked || C.codeKey(currentButton.closest('tr')?.cells[c.codeColumn-1]?.textContent)!==code) throw new Error('Lớp được chọn đã thay đổi trước khi gửi.');
        checkSelection(c,currentButton.closest('tr'));
        const sendButton=namedControl(c,'batchSubmit');
        sent=true;sendButton.click();
      } else {sent = true; currentButton.click();}
      attempts++;updateDashboard(c,ledger);log(`${code}: đã bấm đăng ký; đang đối soát…`);
      const deadline = Date.now() + 20000;
      while (Date.now() < deadline) {
        checkpoint(signal);
        if (fulfilled(c,group,code)) return 'done';
        for (const text of notices) {
          const result = C.classifyNotice(text);
          if (result === 'full' || result === 'blocked') return result;
          if (result === 'auth') throw new Error('Phiên đăng nhập hết hạn.');
        }
        await sleep(250, signal);
      }
      throw new Error(`${code}: chưa xác nhận được kết quả trong bảng đã đăng ký. Không gửi lại tự động.`);
    } catch (e) {
      if (sent) {
        ledger[code] = {state:'uncertain', at:new Date().toISOString()};
        await persist(c, ledger);
      } else { delete ledger[code]; await persist(c, ledger); }
      throw e;
    } finally { observer.disconnect(); }
  }
  async function run(c, signal) {
    let ledger = await reconcile(c);
    const groups=C.parsePlan(c.codes), codes=C.flattenPlan(groups);
    const uncertain = codes.filter(code => ['pending','uncertain'].includes(ledger[code]?.state));
    if (uncertain.length) throw new Error('Cần kiểm tra kết quả trước đó: ' + uncertain.join(', ') + '. Bấm Đối soát sau khi bảng đã đăng ký cập nhật.');
    const start = c.startAt ? Date.parse(c.startAt + ':00+07:00') : Date.now();
    while (Date.now() < start) {
      checkpoint(signal); status('Đang hẹn giờ · còn ' + Math.ceil((start - Date.now()) / 1000) + ' giây (giờ Việt Nam).');
      await sleep(Math.min(1000, start - Date.now()), signal);
    }
    const deadline = c.duration ? Date.now() + c.duration * 60000 : Infinity;
    let round = 0;
    while (Date.now() < deadline) {
      checkpoint(signal); round++;
      status(`Vòng ${round} · đang kiểm tra danh sách…`);
      await refresh(c, signal);
      for (const group of groups) {
        checkpoint(signal);
        if (Date.now() >= deadline) break;
        for(const candidate of group.candidates) if(fulfilled(c,group,candidate.code)) ledger[candidate.code]={state:'done',at:new Date().toISOString()};
        await persist(c,ledger);updateDashboard(c,ledger);
        if(['done','blocked'].includes(C.groupState(group,ledger).state))continue;
        if(!group.switchFrom)await openCourse(c,group,signal);
        for(const candidate of group.candidates) {
          checkpoint(signal);if(Date.now()>=deadline)break;
          const code=candidate.code;
          if(ledger[code]?.state==='blocked')continue;
          if(group.switchFrom)await openSwitch(c,group,signal);
          await search(c, code, signal);
          const actionConfig=group.switchFrom?{...c,action:c.switchTarget,actionLabel:c.switchTargetLabel,actionKind:'button'}:c;
          const result = await submit(actionConfig, code, signal, ledger,candidate,group);
          ledger[code] = {state:result, at:new Date().toISOString()};
          await persist(c, ledger);updateDashboard(c,ledger);
          clearOwnSelection(actionConfig,code);
          log(`${code}: ${ {done:'đã xác minh trong bảng đã đăng ký ✓; dừng các lớp thay thế', full:'chưa có chỗ / nút bị khóa; thử lựa chọn kế tiếp', missing:'chưa thấy mã trong danh sách; chờ vòng sau', mismatch:'không khớp giảng viên/lịch; kiểm tra điều kiện đã nhập', blocked:'bị chặn do điều kiện học vụ; kiểm tra thông báo trên trang'}[result] }`);
          await sleep(1000, signal);
          if(result==='done')break;
        }
      }
      const remaining = groups.filter(group => !['done','blocked'].includes(C.groupState(group,ledger).state));
      if (!remaining.length) {
        const blocked = groups.filter(group => C.groupState(group,ledger).state==='blocked');
        status(blocked.length ? `Đã xử lý danh sách. ${blocked.length} nhóm cần kiểm tra điều kiện: ${blocked.map(g=>g.course || g.id).join(', ')}` : 'Hoàn tất · mỗi nhóm yêu cầu đã có một lớp được xác minh trong bảng đã đăng ký.');
        return;
      }
      status(`Còn ${remaining.length} lớp chờ · vòng ${round}. Kiểm tra lại sau ${c.interval} giây.`);
      await sleep(Math.min(c.interval * 1000, Math.max(1, deadline - Date.now())), signal);
    }
    status('Đã hết thời gian chờ đã cấu hình. Xem nhật ký để biết lớp còn thiếu.');
  }
  function updateDashboard(c,ledger={}) {
    let groups;
    try {groups=C.parsePlan(c.codes);} catch { $('queue').replaceChildren();$('stats').replaceChildren();return; }
    const states=groups.map(g=>C.groupState(g,ledger));
    $('stats').replaceChildren();
    for(const [name,count] of [['Nhóm yêu cầu',groups.length],['Thành công',states.filter(s=>s.state==='done').length],['Đang chờ',states.filter(s=>s.state==='waiting').length],['Lần gửi',attempts]]) {
      const box=document.createElement('div'),b=document.createElement('b');b.textContent=count;box.append(b,document.createTextNode(name));$('stats').append(box);
    }
    $('queue').replaceChildren();
    groups.forEach((g,index)=>{
      const item=document.createElement('div');item.className='queue-item';
      const title=document.createElement('strong');title.textContent=(g.course?`${g.course} · ${g.kind==='TH'?'Thực hành':'Lý thuyết'}`:`Yêu cầu ${index+1}`)+' · '+({done:'✓ Đã đăng ký',waiting:'Đang chờ',uncertain:'Chưa rõ kết quả',blocked:'Lỗi điều kiện'}[states[index].state]);item.append(title);
      const text=document.createElement('div');text.textContent=g.candidates.map(candidate=>candidate.code+(ledger[candidate.code]?.state ? ` [${ledger[candidate.code].state}]`:'')).join(' → ');item.append(text);
      if(g.switchFrom){const old=document.createElement('div');old.textContent='Chuyển từ lớp: '+g.switchFrom;item.append(old);}
      const tools=document.createElement('div');tools.className='tools';
      for(const [name,delta] of [['↑',-1],['↓',1],['Bỏ khỏi kế hoạch',0]]) {
        const b=document.createElement('button');b.textContent=name;b.disabled=running || (delta!==0 && (index+delta<0 || index+delta>=groups.length));
        b.onclick=async()=>{try{const next=C.parsePlan(readConfig().codes);const [picked]=next.splice(index,1);if(delta)next.splice(index+delta,0,picked);$('codes').value=C.serializePlan(next);await save();updateDashboard(config,await getLedger(config));}catch(e){status(e.message);}};
        tools.append(b);
      }
      item.append(tools);$('queue').append(item);
    });
  }
  function downloadFile(name,text,type) {
    const url=URL.createObjectURL(new Blob([text],{type}));const link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function catalog(c,courseTable=false) {
    const table=tableFor(c,courseTable?'courses':'available'),h=headers(table);
    const idx=(pattern)=>h.findIndex(s=>pattern.test(s));
    const teacher=idx(/giang vien/),schedule=idx(/lich hoc|thong tin/),kind=idx(/^loai$/),name=idx(/ten (hp|hoc phan|mon)/);
    const codeCol=(courseTable?c.courseColumn:c.codeColumn)-1;
    const values=[];
    for(const row of table.querySelectorAll('tbody tr')) {
      if(!visible(row))continue;
      const code=C.codeKey(row.cells[codeCol]?.textContent);
      try {if(C.parseCodes(code).length!==1)continue;}catch{continue;}
      values.push({code,course:courseTable?code:C.codeKey($('catalogCourse').value),name:row.cells[name]?.textContent.trim() || '',teacher:row.cells[teacher]?.textContent.trim() || '',schedule:row.cells[schedule]?.textContent.trim() || '',kind:C.normalize(row.cells[kind]?.textContent).includes('thuc hanh')?'TH':$('catalogKind').value,isCourse:courseTable});
    }
    return values;
  }
  function renderCatalog() {
    $('catalog').replaceChildren();
    const filter=C.normalize($('catalogFilter').value);
    const selected=document.createElement('div');selected.className='catalog-title';selected.textContent=`${catalogRows.length} dòng đã đọc · ${catalogSelection.size} lớp đã chọn`; $('catalog').append(selected);
    const wrap=document.createElement('div');wrap.className='catalog-wrap';const table=document.createElement('table');table.className='catalog';
    const header=document.createElement('tr');for(const name of ['Chọn','Mã','Tên / Giảng viên','Lịch học']){const th=document.createElement('th');th.textContent=name;header.append(th);}table.append(header);
    catalogRows.filter(row=>!filter || C.normalize([row.code,row.name,row.teacher,row.schedule].join(' ')).includes(filter)).forEach(row=>{
      const tr=document.createElement('tr'),choose=document.createElement('td');
      if(row.isCourse) {
        const b=document.createElement('button');b.textContent='Mở lớp';b.disabled=running;
        b.onclick=async()=>{
          if(running)return;controller=new AbortController();setRunning(true);
          try{await save();if(!navigator.locks)throw new Error('Cần trình duyệt hỗ trợ Web Locks.');await navigator.locks.request('hcmute-dkmh-single-runner',{ifAvailable:true},async lock=>{if(!lock)throw new Error('Một tab khác đang chạy tool.');await openCourse(config,{course:row.code},controller.signal);$('catalogCourse').value=row.code;catalogRows=catalog(config);catalogSelection.clear();renderCatalog();status('Đã mở lớp của '+row.code+'. Chọn các lớp theo thứ tự ưu tiên.');});}catch(e){status(e.message);}finally{setRunning(false);renderCatalog();}
        };choose.append(b);
      } else {
        const cb=document.createElement('input');cb.type='checkbox';cb.setAttribute('aria-label','Chọn '+row.code);cb.checked=catalogSelection.has(row.code);cb.disabled=running;
        cb.onchange=()=>{if(cb.checked)catalogSelection.add(row.code);else catalogSelection.delete(row.code);renderCatalog();};choose.append(cb);
      }
      tr.append(choose);
      for(const text of [row.code,[row.name,row.teacher].filter(Boolean).join(' · '),row.schedule]) {const td=document.createElement('td');td.textContent=text;tr.append(td);}table.append(tr);
    });
    wrap.append(table);$('catalog').append(wrap);
  }
  function setRunning(value) {
    running = value;
    for (const el of ui.querySelectorAll('input,textarea,select,main button')) el.disabled = value;
    $('stop').disabled = !value;
    window.removeEventListener('beforeunload', beforeUnload);
    if (value) window.addEventListener('beforeunload', beforeUnload);
  }
  function beforeUnload(e) { e.preventDefault(); e.returnValue = ''; }
  $('minimize').onclick = () => { ui.querySelector('.panel').classList.add('hidden'); $('expand').classList.remove('hidden'); };
  $('expand').onclick = () => { ui.querySelector('.panel').classList.remove('hidden'); $('expand').classList.add('hidden'); };
  ui.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => pick(b.dataset.pick));
  fields.forEach(f => $(f).addEventListener('change', () => save().catch(e => status('Không lưu được cấu hình: ' + e.message))));
  $('catalogFilter').oninput=renderCatalog;
  $('loadPlan').onclick=async()=>{try{await save();C.parsePlan(config.codes);updateDashboard(config,await getLedger(config));status('Đã cập nhật danh sách. Chưa gửi đăng ký.');}catch(e){status(e.message);}};
  $('scanCatalog').onclick=async()=>{try{await save();catalogRows=catalog(config);catalogSelection.clear();renderCatalog();status('Đã đọc bảng lớp. Chưa gửi đăng ký.');}catch(e){status(e.message);}};
  $('scanCourses').onclick=async()=>{try{await save();if(!config.courses)throw new Error('Chưa chọn bảng môn cha trong Thiết lập giao diện.');catalogRows=catalog(config,true);catalogSelection.clear();renderCatalog();}catch(e){status(e.message);}};
  $('addCatalog').onclick=async()=>{
    try {
      if(!catalogSelection.size)throw new Error('Chọn ít nhất một lớp trong bảng.');
      const current=readConfig().codes.trim();let groups=current?C.parsePlan(current):[];
      for(const code of catalogSelection) {
        const matches=catalogRows.filter(r=>r.code===code && !r.isCourse);
        if(matches.length!==1)throw new Error('Mã '+code+' không duy nhất trong bảng đã đọc.');
        const row=matches[0],course=C.codeKey(row.course || $('catalogCourse').value);
        if(!course || C.parseCodes(course).length!==1)throw new Error('Nhập mã môn của bảng lớp để ghép các lớp thay thế đúng môn.');
        if(C.flattenPlan(groups).includes(code))continue;
        let g=groups.find(g=>g.course===course && g.kind===row.kind);
        if(!g){g={id:course+':'+row.kind,course,kind:row.kind,candidates:[]};groups.push(g);}
        g.candidates.push({code,teacher:row.teacher || '*',schedule:row.schedule || '*'});
      }
      $('codes').value=C.serializePlan(groups);await save();updateDashboard(config,await getLedger(config));catalogSelection.clear();renderCatalog();status('Đã thêm vào kế hoạch. Thứ tự chọn là thứ tự ưu tiên.');
    }catch(e){status(e.message);}
  };
  $('exportPlan').onclick=async()=>{try{await save();const groups=C.parsePlan(config.codes);downloadFile('hcmute-ke-hoach.json',JSON.stringify({version:1,scope:config.scope,registrationMode:config.registrationMode,groups},null,2),'application/json');status('Đã xuất kế hoạch, không gồm phiên đăng nhập hay ánh xạ DOM.');}catch(e){status(e.message);}};
  $('importPlan').onclick=()=>$('planFile').click();
  $('planFile').onchange=async()=>{
    try{
      const file=$('planFile').files[0];if(!file)return;if(file.size>1024*1024)throw new Error('Kế hoạch tối đa 1 MB.');
      const text=await file.text();let codes=text;
      if(file.name.toLowerCase().endsWith('.json')) {const data=JSON.parse(text);if(data.version!==1 || !Array.isArray(data.groups))throw new Error('Không đúng định dạng kế hoạch.');codes=C.serializePlan(data.groups);}
      C.parsePlan(codes);$('codes').value=codes;await save();updateDashboard(config,await getLedger(config));status('Đã nạp kế hoạch. Kiểm tra đúng học kỳ/đợt trước khi chạy.');
    }catch(e){status(e.message);}finally{$('planFile').value='';}
  };
  $('exportResults').onclick=async()=>{
    try{await save();const ledger=await getLedger(config);const rows=[['Mã môn','Loại','Mã LHP','Ưu tiên','Trạng thái','Cập nhật']];for(const g of C.parsePlan(config.codes))g.candidates.forEach((candidate,i)=>rows.push([g.course,g.kind,candidate.code,i+1,ledger[candidate.code]?.state || (C.groupState(g,ledger).state==='done'?'skipped':'waiting'),ledger[candidate.code]?.at || '']));const cell=v=>'"'+String(v).replace(/^([=+@-])/,'\'$1').replace(/"/g,'""')+'"';downloadFile('hcmute-ket-qua.csv','\uFEFF'+rows.map(r=>r.map(cell).join(',')).join('\r\n'),'text/csv;charset=utf-8');}catch(e){status(e.message);}
  };
  $('clearSearch').onclick = async () => { delete config.searchInput; delete config.searchButton; marks(); await save(); };
  $('clearCourses').onclick=async()=>{delete config.courses;delete config.courseAction;marks();await save();};
  $('previewButton').onclick = async () => { try { cancelPick(); await save(); $('preview').textContent = preview(config); status('Xem trước hoàn tất. Chưa bấm đăng ký.'); } catch (e) { status(e.message); log(e.message); } };
  $('start').onclick = async () => {
    if (running) return;
    // Reserve synchronously: rapid double clicks must not create two controllers.
    controller = new AbortController(); setRunning(true);
    status('Đang chuẩn bị danh sách và kiểm tra giao diện…');
    try {
      cancelPick(); await save(); C.validateConfig(config); $('preview').textContent = preview(config);
      if (!navigator.locks) throw new Error('Trình duyệt thiếu Web Locks. Hãy dùng Chrome/Edge mới để tránh hai tab chạy đồng thời.');
      const c = structuredClone(config);
      log('Bắt đầu · mỗi lần chỉ gửi một lớp.');
      await navigator.locks.request('hcmute-dkmh-single-runner', { ifAvailable: true }, async lock => {
        if (!lock) throw new Error('Một tab khác đang chạy tool. Hãy dừng tab đó trước.');
        await run(c, controller.signal);
      });
    } catch (e) { status(e.name === 'AbortError' ? 'Đã dừng. Lần gửi đang xử lý (nếu có) vẫn có thể hoàn tất trên máy chủ; hãy đối soát.' : e.message); log($('status').textContent); }
    finally { setRunning(false);try{updateDashboard(config,await getLedger(config));}catch{} }
  };
  $('stop').onclick = () => { controller?.abort(); status('Đang dừng…'); };
  $('reconcile').onclick = async () => {
    try { await save(); C.validateConfig(config); ensurePage(); const ledger = await reconcile(config); const lines = C.flattenPlan(C.parsePlan(config.codes)).map(code => `${code}: ${ledger[code]?.state || 'chưa gửi'}`); log(lines.join('\n')); status('Đã đối soát. pending/uncertain cần kiểm tra thủ công nếu chưa có trong bảng.'); }
    catch (e) { status(e.message); }
  };
  $('reset').onclick = async () => {
    try {
      await save(); if (!config.scope) throw new Error('Chưa nhập học kỳ / đợt.');
      if (!window.confirm('Xóa toàn bộ nhật ký đợt “' + config.scope + '”? Chỉ tiếp tục nếu đã kiểm tra không còn yêu cầu đang xử lý. Xóa có thể cho phép gửi lại mã cũ.')) return;
      await storage.set(ledgerKey(config), {}); status('Đã xóa nhật ký đợt này. Không thay đổi đăng ký trên website.');
    } catch (e) { status(e.message); }
  };
  (async () => {
    try {
      config = { ...defaults, ...(await storage.get('settings') || {}) };
      for (const f of fields) $(f).value = config[f];
      marks();
      updateDashboard(config,config.scope?await getLedger(config):{});
      if (!config.available) $('mapping').open = true;
      log('Đã tải tool. Chỉ chạy sau khi bạn bấm Bắt đầu.');
    } catch (e) { status('Không truy cập được kho lưu cục bộ: ' + e.message); $('start').disabled = true; }
  })();
})();
